import { Link, useRouterState } from "@tanstack/react-router";
import {
  LayoutDashboard,
  Car,
  Wrench,
  Users,
  ClipboardList,
  Flag,
  Trophy,
  BarChart3,
  Settings,
  Bell,
  Wallet,
  CalendarDays,
  ChevronRight,
} from "lucide-react";
import type { ReactNode } from "react";

const NAV = [
  { to: "/", label: "Painel", icon: LayoutDashboard },
  { to: "/equipe", label: "Minha Equipe", icon: Car },
  { to: "/desenvolvimento", label: "Desenvolvimento", icon: Wrench },
  { to: "/treinamento", label: "Treinamento", icon: Users },
  { to: "/estrategia", label: "Estratégia", icon: ClipboardList },
  { to: "/corridas", label: "Corridas", icon: Flag },
  { to: "/temporada", label: "Temporada", icon: Trophy },
  { to: "/classificacao", label: "Classificação", icon: BarChart3 },
  { to: "/administracao", label: "Administração", icon: Settings },
] as const;

export function AppLayout({ children, title, subtitle }: { children: ReactNode; title?: string; subtitle?: string }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  return (
    <div className="min-h-screen w-full text-foreground">
      {/* Sidebar */}
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-64 flex-col border-r border-[var(--border-color)] bg-[var(--sidebar)] lg:flex">
        <div className="flex items-center gap-3 px-5 py-5 border-b border-[var(--border-color)]">
          <div className="brand-gradient grid h-10 w-10 place-items-center rounded-lg shadow-lg">
            <svg viewBox="0 0 24 24" className="h-6 w-6" fill="none" stroke="var(--brand-secondary)" strokeWidth="2.2">
              <circle cx="7" cy="17" r="2.5" />
              <circle cx="17" cy="17" r="2.5" />
              <path d="M3 15l2-4h6l3-3h4l3 5v2" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </div>
          <div className="min-w-0">
            <div className="text-[11px] uppercase tracking-[0.2em] text-muted-foreground">Open Wheel</div>
            <div className="truncate text-sm font-bold">STRATEGY</div>
          </div>
        </div>

        <nav className="flex-1 overflow-y-auto px-3 py-4">
          <div className="mb-2 px-3 text-[10px] uppercase tracking-[0.22em] text-muted-foreground">Comando</div>
          <ul className="space-y-1">
            {NAV.map(({ to, label, icon: Icon }) => {
              const active = pathname === to;
              return (
                <li key={to}>
                  <Link
                    to={to}
                    className={`group flex items-center gap-3 rounded-md px-3 py-2.5 text-sm transition-all ${
                      active
                        ? "bg-[color-mix(in_oklab,var(--brand-primary)_18%,transparent)] text-foreground shadow-[inset_2px_0_0_var(--brand-primary)]"
                        : "text-muted-foreground hover:bg-[var(--surface-2)] hover:text-foreground"
                    }`}
                  >
                    <Icon className={`h-4 w-4 ${active ? "text-[var(--brand-primary)]" : ""}`} />
                    <span className="truncate">{label}</span>
                    {active && <ChevronRight className="ml-auto h-4 w-4 text-[var(--brand-primary)]" />}
                  </Link>
                </li>
              );
            })}
          </ul>
        </nav>

        <div className="border-t border-[var(--border-color)] p-4">
          <div className="surface-card p-3">
            <div className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">Equipe</div>
            <div className="mt-1 text-sm font-semibold">Apex Racing</div>
            <div className="mt-2 h-1.5 w-full overflow-hidden rounded-full bg-[var(--surface-3)]">
              <div className="h-full brand-gradient" style={{ width: "68%" }} />
            </div>
            <div className="mt-1.5 flex justify-between text-[10px] text-muted-foreground">
              <span>Moral</span>
              <span className="text-mono text-foreground">68%</span>
            </div>
          </div>
        </div>
      </aside>

      {/* Main */}
      <div className="lg:pl-64">
        {/* Topbar */}
        <header className="sticky top-0 z-20 border-b border-[var(--border-color)] bg-[color-mix(in_oklab,var(--background)_85%,transparent)] backdrop-blur-xl">
          <div className="flex h-16 items-center gap-4 px-4 md:px-6">
            <div className="lg:hidden brand-gradient grid h-9 w-9 place-items-center rounded-md">
              <Car className="h-5 w-5" style={{ color: "var(--brand-secondary)" }} />
            </div>
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-2 text-[11px] uppercase tracking-[0.2em] text-muted-foreground">
                <span className="hidden md:inline">Open Wheel Strategy</span>
                <span className="hidden md:inline">/</span>
                <span className="truncate">{subtitle ?? "Comando de Equipe"}</span>
              </div>
              <h1 className="truncate text-lg font-bold leading-tight md:text-xl">{title ?? "Painel"}</h1>
            </div>

            <div className="hidden items-center gap-2 md:flex">
              <TopStat icon={CalendarDays} label="Temporada" value="2026 • R7/22" />
              <TopStat icon={Wallet} label="Saldo" value="$ 42.8M" accent />
            </div>

            <button className="grid h-10 w-10 place-items-center rounded-md border border-[var(--border-color)] bg-[var(--surface-2)] hover:bg-[var(--surface-3)]">
              <Bell className="h-4 w-4" />
            </button>

            <div className="flex items-center gap-3 rounded-md border border-[var(--border-color)] bg-[var(--surface-2)] px-2.5 py-1.5">
              <div className="brand-gradient grid h-7 w-7 place-items-center rounded-full text-[11px] font-bold" style={{ color: "var(--brand-secondary)" }}>
                JR
              </div>
              <div className="hidden text-left leading-tight sm:block">
                <div className="text-[11px] text-muted-foreground">Team Principal</div>
                <div className="text-xs font-semibold">J. Rossi</div>
              </div>
            </div>
          </div>
        </header>

        <main className="mx-auto max-w-[1400px] px-4 py-6 md:px-6 md:py-8">{children}</main>
      </div>
    </div>
  );
}

function TopStat({
  icon: Icon,
  label,
  value,
  accent,
}: {
  icon: typeof Bell;
  label: string;
  value: string;
  accent?: boolean;
}) {
  return (
    <div className="flex items-center gap-2.5 rounded-md border border-[var(--border-color)] bg-[var(--surface-2)] px-3 py-1.5">
      <Icon className={`h-4 w-4 ${accent ? "text-[var(--brand-primary)]" : "text-muted-foreground"}`} />
      <div className="leading-tight">
        <div className="text-[10px] uppercase tracking-widest text-muted-foreground">{label}</div>
        <div className={`text-mono text-xs font-semibold ${accent ? "text-[var(--brand-primary)]" : ""}`}>{value}</div>
      </div>
    </div>
  );
}