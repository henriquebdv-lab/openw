import { createFileRoute } from "@tanstack/react-router";
import { AppLayout } from "@/components/AppLayout";
import { Cog, Fuel, CircleDot, Shield, Settings2, Waves, HardHat } from "lucide-react";
import type { ComponentType } from "react";

export const Route = createFileRoute("/equipe")({
  head: () => ({ meta: [{ title: "Minha Equipe — Open Wheel Strategy" }] }),
  component: Equipe,
});

type Supplier = {
  category: string;
  icon: ComponentType<{ className?: string }>;
  name: string;
  supplier: string;
  annual: string;
  perRace: string;
  efficiency: number;
  tier: "S" | "A" | "B" | "C";
};

const COMPONENTS: Supplier[] = [
  { category: "Motor", icon: Cog, name: "V6 Turbo Híbrido", supplier: "Falken Powertrain", annual: "$ 14.2M", perRace: "$ 640K", efficiency: 92, tier: "S" },
  { category: "Combustível", icon: Fuel, name: "OctaMax Pro", supplier: "Nordic Fuels", annual: "$ 3.8M", perRace: "$ 172K", efficiency: 84, tier: "A" },
  { category: "Pneus", icon: CircleDot, name: "GripLine C4", supplier: "Vortex Rubber", annual: "$ 5.6M", perRace: "$ 254K", efficiency: 88, tier: "A" },
  { category: "Chassi", icon: Shield, name: "Monocoque MX-7", supplier: "Carbon Foundry", annual: "$ 9.1M", perRace: "$ 413K", efficiency: 79, tier: "B" },
  { category: "Câmbio", icon: Settings2, name: "8-Speed Quantum", supplier: "Zenith Drives", annual: "$ 4.2M", perRace: "$ 190K", efficiency: 86, tier: "A" },
  { category: "Suspensão", icon: Waves, name: "AdaptiveArm v3", supplier: "Helix Dynamics", annual: "$ 2.9M", perRace: "$ 131K", efficiency: 74, tier: "B" },
  { category: "Engenheiro Chefe", icon: HardHat, name: "L. Marchetti", supplier: "Contrato exclusivo", annual: "$ 3.5M", perRace: "—", efficiency: 90, tier: "S" },
];

const TIER: Record<Supplier["tier"], string> = {
  S: "text-[var(--brand-primary)] border-[var(--brand-primary)]",
  A: "text-emerald-400 border-emerald-500/40",
  B: "text-amber-400 border-amber-500/40",
  C: "text-rose-400 border-rose-500/40",
};

function Equipe() {
  const totalAnnual = 43.3;
  return (
    <AppLayout title="Minha Equipe" subtitle="Fornecedores & Componentes">
      <div className="mb-6 grid grid-cols-1 gap-4 md:grid-cols-3">
        <div className="surface-card p-5">
          <div className="text-[11px] uppercase tracking-widest text-muted-foreground">Custo anual total</div>
          <div className="text-mono mt-1 text-3xl font-black">$ {totalAnnual}<span className="text-lg text-muted-foreground">M</span></div>
        </div>
        <div className="surface-card p-5">
          <div className="text-[11px] uppercase tracking-widest text-muted-foreground">Eficiência média</div>
          <div className="text-mono mt-1 text-3xl font-black text-[var(--brand-primary)]">84.7%</div>
        </div>
        <div className="surface-card p-5">
          <div className="text-[11px] uppercase tracking-widest text-muted-foreground">Contratos ativos</div>
          <div className="text-mono mt-1 text-3xl font-black">7</div>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3">
        {COMPONENTS.map((c) => (
          <div key={c.category} className="surface-card group relative overflow-hidden p-5 transition hover:border-[var(--brand-primary)]/40">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3">
                <div className="grid h-11 w-11 place-items-center rounded-md bg-[var(--surface-3)] text-[var(--brand-primary)]">
                  <c.icon className="h-5 w-5" />
                </div>
                <div>
                  <div className="text-[10px] uppercase tracking-widest text-muted-foreground">{c.category}</div>
                  <div className="text-base font-bold">{c.name}</div>
                </div>
              </div>
              <span className={`rounded-md border px-2 py-0.5 text-mono text-xs font-bold bg-[var(--surface-2)] ${TIER[c.tier]}`}>
                {c.tier}
              </span>
            </div>

            <div className="mt-4 text-xs text-muted-foreground">Fornecedor</div>
            <div className="text-sm font-medium">{c.supplier}</div>

            <div className="mt-4 grid grid-cols-2 gap-2 text-xs">
              <div className="rounded-md border border-[var(--border-color)] bg-[var(--surface-2)] p-2.5">
                <div className="text-muted-foreground">Custo anual</div>
                <div className="text-mono text-sm font-semibold">{c.annual}</div>
              </div>
              <div className="rounded-md border border-[var(--border-color)] bg-[var(--surface-2)] p-2.5">
                <div className="text-muted-foreground">Por corrida</div>
                <div className="text-mono text-sm font-semibold">{c.perRace}</div>
              </div>
            </div>

            <div className="mt-4">
              <div className="mb-1 flex justify-between text-[11px]">
                <span className="text-muted-foreground">Eficiência</span>
                <span className="text-mono font-semibold">{c.efficiency}%</span>
              </div>
              <div className="h-1.5 w-full overflow-hidden rounded-full bg-[var(--surface-3)]">
                <div className="h-full brand-gradient" style={{ width: `${c.efficiency}%` }} />
              </div>
            </div>
          </div>
        ))}
      </div>
    </AppLayout>
  );
}