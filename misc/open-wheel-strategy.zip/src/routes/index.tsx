import { createFileRoute } from "@tanstack/react-router";
import { AppLayout } from "@/components/AppLayout";
import {
  Cloud,
  Flag,
  Trophy,
  Wallet,
  Wrench,
  Users,
  ThermometerSun,
  Clock,
  ArrowUpRight,
  ArrowDownRight,
  Timer,
} from "lucide-react";

export const Route = createFileRoute("/")({ component: Dashboard });

function Dashboard() {
  return (
    <AppLayout title="Centro de Comando" subtitle="Painel">
      <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3">
        {/* Next Race — hero */}
        <div className="surface-card-elevated relative overflow-hidden p-6 md:col-span-2 xl:col-span-2">
          <div className="absolute inset-0 opacity-20" style={{
            backgroundImage:
              "linear-gradient(135deg, var(--brand-primary) 0%, transparent 55%)",
          }} />
          <div className="relative flex items-start justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 text-[11px] uppercase tracking-[0.24em] text-muted-foreground">
                <Flag className="h-3.5 w-3.5" /> Próxima Corrida • R7
              </div>
              <h2 className="mt-2 text-3xl font-black tracking-tight md:text-4xl">Grande Prêmio de Mônaco</h2>
              <div className="mt-1 text-sm text-muted-foreground">Circuit de Monaco — Monte Carlo</div>
            </div>
            <div className="text-right">
              <div className="text-[11px] uppercase tracking-widest text-muted-foreground">Faltam</div>
              <div className="text-mono text-2xl font-bold text-[var(--brand-primary)]">03d 14h</div>
            </div>
          </div>

          <div className="relative mt-6 grid grid-cols-2 gap-3 md:grid-cols-4">
            <Metric icon={Timer} label="Voltas" value="78" />
            <Metric icon={Clock} label="Comp." value="3.337 km" />
            <Metric icon={ThermometerSun} label="Temp." value="24°C" />
            <Metric icon={Cloud} label="Clima" value="Nublado" />
          </div>

          <div className="relative mt-6 flex flex-wrap gap-2">
            <button className="brand-gradient rounded-md px-4 py-2 text-sm font-semibold shadow" style={{ color: "var(--brand-secondary)" }}>
              Definir Estratégia
            </button>
            <button className="rounded-md border border-[var(--border-strong)] bg-[var(--surface-2)] px-4 py-2 text-sm font-semibold hover:bg-[var(--surface-3)]">
              Simular Qualificação
            </button>
          </div>
        </div>

        {/* Championship position */}
        <StatCard icon={Trophy} label="Posição no Campeonato">
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-mono text-5xl font-black text-[var(--brand-primary)]">3</span>
            <span className="text-lg text-muted-foreground">/ 10</span>
          </div>
          <div className="mt-3 flex items-center gap-2 text-xs text-emerald-400">
            <ArrowUpRight className="h-3.5 w-3.5" /> +1 desde a última corrida
          </div>
          <div className="mt-4 text-mono text-sm">
            <span className="text-muted-foreground">Pontos:</span>{" "}
            <span className="font-semibold">248</span>
            <span className="mx-2 text-muted-foreground">·</span>
            <span className="text-muted-foreground">Gap líder:</span>{" "}
            <span className="font-semibold">-42</span>
          </div>
        </StatCard>

        <StatCard icon={Wallet} label="Orçamento" tone="primary">
          <div className="mt-2 text-mono text-4xl font-black">$ 42.8<span className="text-xl text-muted-foreground">M</span></div>
          <div className="mt-1 flex items-center gap-2 text-xs text-rose-400">
            <ArrowDownRight className="h-3.5 w-3.5" /> -$ 2.4M esta semana
          </div>
          <Bar value={57} label="Do teto orçamentário" />
        </StatCard>

        <StatCard icon={Wrench} label="Desenvolvimento do Carro">
          <div className="mt-3 space-y-2.5">
            <DevRow name="Aerodinâmica" value={82} />
            <DevRow name="Motor" value={71} />
            <DevRow name="Chassi" value={64} />
            <DevRow name="Confiabilidade" value={88} />
          </div>
        </StatCard>

        <StatCard icon={Users} label="Treinamento de Boxes">
          <div className="mt-2 flex items-end gap-3">
            <div className="text-mono text-4xl font-black">2.31<span className="text-lg text-muted-foreground">s</span></div>
            <div className="text-xs text-emerald-400">-0.14s ▲</div>
          </div>
          <Bar value={78} label="Sincronia da equipe" />
          <div className="mt-3 grid grid-cols-3 gap-2 text-center text-[11px]">
            {["Frontal", "Traseira", "Jack"].map((r) => (
              <div key={r} className="rounded-md border border-[var(--border-color)] bg-[var(--surface-2)] py-1.5">
                <div className="text-muted-foreground">{r}</div>
                <div className="text-mono text-sm font-semibold">A</div>
              </div>
            ))}
          </div>
        </StatCard>

        {/* Recent races */}
        <div className="surface-card p-6 md:col-span-2 xl:col-span-3">
          <div className="mb-4 flex items-center justify-between">
            <div>
              <div className="text-[11px] uppercase tracking-widest text-muted-foreground">Últimas Corridas</div>
              <h3 className="text-lg font-bold">Histórico Recente</h3>
            </div>
            <button className="text-xs text-muted-foreground hover:text-foreground">Ver tudo →</button>
          </div>
          <div className="grid grid-cols-2 gap-3 md:grid-cols-3 lg:grid-cols-6">
            {[
              { gp: "Austrália", pos: 4, pts: 12, flag: "🇦🇺" },
              { gp: "Japão", pos: 2, pts: 18, flag: "🇯🇵" },
              { gp: "China", pos: 6, pts: 8, flag: "🇨🇳" },
              { gp: "Bahrein", pos: 3, pts: 15, flag: "🇧🇭" },
              { gp: "Espanha", pos: 1, pts: 25, flag: "🇪🇸" },
              { gp: "Itália", pos: 5, pts: 10, flag: "🇮🇹" },
            ].map((r) => (
              <div key={r.gp} className="rounded-md border border-[var(--border-color)] bg-[var(--surface-2)] p-3">
                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <span>{r.flag} {r.gp}</span>
                  <span className="text-mono">+{r.pts}pts</span>
                </div>
                <div className="mt-2 flex items-baseline gap-1">
                  <span className={`text-mono text-2xl font-black ${r.pos === 1 ? "text-[var(--brand-primary)]" : ""}`}>P{r.pos}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </AppLayout>
  );
}

function Metric({ icon: Icon, label, value }: { icon: typeof Flag; label: string; value: string }) {
  return (
    <div className="rounded-lg border border-[var(--border-color)] bg-[var(--surface-2)]/60 p-3">
      <div className="flex items-center gap-2 text-[11px] uppercase tracking-widest text-muted-foreground">
        <Icon className="h-3.5 w-3.5" /> {label}
      </div>
      <div className="text-mono mt-1 text-xl font-bold">{value}</div>
    </div>
  );
}

function StatCard({
  icon: Icon,
  label,
  children,
  tone,
}: {
  icon: typeof Flag;
  label: string;
  children: React.ReactNode;
  tone?: "primary";
}) {
  return (
    <div className="surface-card relative overflow-hidden p-5">
      {tone === "primary" && (
        <div className="absolute inset-x-0 top-0 h-0.5 brand-gradient" />
      )}
      <div className="flex items-center gap-2 text-[11px] uppercase tracking-[0.22em] text-muted-foreground">
        <Icon className="h-3.5 w-3.5" /> {label}
      </div>
      {children}
    </div>
  );
}

function Bar({ value, label }: { value: number; label: string }) {
  return (
    <div className="mt-3">
      <div className="h-1.5 w-full overflow-hidden rounded-full bg-[var(--surface-3)]">
        <div className="h-full brand-gradient" style={{ width: `${value}%` }} />
      </div>
      <div className="mt-1.5 flex justify-between text-[10px] text-muted-foreground">
        <span>{label}</span>
        <span className="text-mono text-foreground">{value}%</span>
      </div>
    </div>
  );
}

function DevRow({ name, value }: { name: string; value: number }) {
  return (
    <div>
      <div className="mb-1 flex justify-between text-xs">
        <span className="text-muted-foreground">{name}</span>
        <span className="text-mono font-semibold">{value}</span>
      </div>
      <div className="h-1.5 w-full overflow-hidden rounded-full bg-[var(--surface-3)]">
        <div className="h-full brand-gradient" style={{ width: `${value}%` }} />
      </div>
    </div>
  );
}
