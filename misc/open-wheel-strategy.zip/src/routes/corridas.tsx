import { createFileRoute } from "@tanstack/react-router";
import { AppLayout } from "@/components/AppLayout";
import { Flag } from "lucide-react";

export const Route = createFileRoute("/corridas")({
  head: () => ({ meta: [{ title: "Corridas — Open Wheel Strategy" }] }),
  component: Races,
});

const RACES = [
  { gp: "Austrália", flag: "🇦🇺", date: "12 Mar", pos: 4, status: "done" as const },
  { gp: "Japão", flag: "🇯🇵", date: "26 Mar", pos: 2, status: "done" as const },
  { gp: "China", flag: "🇨🇳", date: "09 Abr", pos: 6, status: "done" as const },
  { gp: "Bahrein", flag: "🇧🇭", date: "23 Abr", pos: 3, status: "done" as const },
  { gp: "Espanha", flag: "🇪🇸", date: "07 Mai", pos: 1, status: "done" as const },
  { gp: "Itália", flag: "🇮🇹", date: "21 Mai", pos: 5, status: "done" as const },
  { gp: "Mônaco", flag: "🇲🇨", date: "04 Jun", pos: null, status: "next" as const },
  { gp: "Canadá", flag: "🇨🇦", date: "18 Jun", pos: null, status: "upcoming" as const },
  { gp: "Áustria", flag: "🇦🇹", date: "02 Jul", pos: null, status: "upcoming" as const },
  { gp: "Reino Unido", flag: "🇬🇧", date: "16 Jul", pos: null, status: "upcoming" as const },
];

function Races() {
  return (
    <AppLayout title="Calendário de Corridas" subtitle="Temporada 2026">
      <div className="surface-card overflow-hidden">
        <div className="grid grid-cols-[auto_1fr_auto_auto_auto] gap-4 border-b border-[var(--border-color)] px-5 py-3 text-[10px] uppercase tracking-widest text-muted-foreground">
          <span>#</span><span>Grande Prêmio</span><span>Data</span><span>Posição</span><span>Status</span>
        </div>
        {RACES.map((r, i) => (
          <div key={r.gp} className="grid grid-cols-[auto_1fr_auto_auto_auto] items-center gap-4 border-b border-[var(--border-color)] px-5 py-4 last:border-0 hover:bg-[var(--surface-2)]">
            <span className="text-mono text-xs text-muted-foreground">R{String(i + 1).padStart(2, "0")}</span>
            <div className="flex items-center gap-3">
              <span className="text-lg">{r.flag}</span>
              <span className="font-semibold">{r.gp}</span>
            </div>
            <span className="text-mono text-xs text-muted-foreground">{r.date}</span>
            <span className="text-mono w-10 text-right font-bold">
              {r.pos ? (
                <span className={r.pos === 1 ? "text-[var(--brand-primary)]" : ""}>P{r.pos}</span>
              ) : (
                <span className="text-muted-foreground">—</span>
              )}
            </span>
            <span
              className={`rounded-md px-2 py-1 text-[10px] uppercase tracking-widest ${
                r.status === "done"
                  ? "bg-[var(--surface-3)] text-muted-foreground"
                  : r.status === "next"
                    ? "brand-gradient font-bold"
                    : "border border-[var(--border-color)] text-muted-foreground"
              }`}
              style={r.status === "next" ? { color: "var(--brand-secondary)" } : undefined}
            >
              {r.status === "done" ? "Concluída" : r.status === "next" ? "Próxima" : "Futura"}
            </span>
          </div>
        ))}
        <div className="flex items-center gap-2 px-5 py-3 text-xs text-muted-foreground">
          <Flag className="h-3.5 w-3.5" /> 22 corridas no calendário
        </div>
      </div>
    </AppLayout>
  );
}