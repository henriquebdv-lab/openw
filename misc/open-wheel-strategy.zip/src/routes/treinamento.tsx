import { createFileRoute } from "@tanstack/react-router";
import { AppLayout } from "@/components/AppLayout";
import { Timer, Users, Zap } from "lucide-react";

export const Route = createFileRoute("/treinamento")({
  head: () => ({ meta: [{ title: "Treinamento — Open Wheel Strategy" }] }),
  component: Training,
});

const CREW = [
  { role: "Front Jack", name: "M. Andersen", level: 92 },
  { role: "Rear Jack", name: "T. Okafor", level: 88 },
  { role: "Wheel Gun FL", name: "R. Silva", level: 84 },
  { role: "Wheel Gun FR", name: "K. Yamada", level: 86 },
  { role: "Wheel Gun RL", name: "A. Dubois", level: 79 },
  { role: "Wheel Gun RR", name: "P. Kohler", level: 81 },
  { role: "Lollipop", name: "S. Rossi", level: 90 },
];

function Training() {
  return (
    <AppLayout title="Treinamento de Boxes" subtitle="Pit Crew">
      <div className="mb-6 grid grid-cols-1 gap-4 md:grid-cols-3">
        <div className="surface-card-elevated p-6">
          <div className="flex items-center gap-2 text-[11px] uppercase tracking-widest text-muted-foreground">
            <Timer className="h-3.5 w-3.5" /> Melhor Pit Stop
          </div>
          <div className="text-mono mt-2 text-5xl font-black text-[var(--brand-primary)]">2.19s</div>
          <div className="mt-1 text-xs text-muted-foreground">Baréim • Q3</div>
        </div>
        <div className="surface-card p-6">
          <div className="flex items-center gap-2 text-[11px] uppercase tracking-widest text-muted-foreground">
            <Zap className="h-3.5 w-3.5" /> Média da temporada
          </div>
          <div className="text-mono mt-2 text-5xl font-black">2.46s</div>
          <div className="mt-1 text-xs text-emerald-400">-0.11s vs. 2025</div>
        </div>
        <div className="surface-card p-6">
          <div className="flex items-center gap-2 text-[11px] uppercase tracking-widest text-muted-foreground">
            <Users className="h-3.5 w-3.5" /> Sincronia da equipe
          </div>
          <div className="text-mono mt-2 text-5xl font-black">87%</div>
          <div className="mt-3 h-2 w-full overflow-hidden rounded-full bg-[var(--surface-3)]">
            <div className="h-full brand-gradient" style={{ width: "87%" }} />
          </div>
        </div>
      </div>

      <div className="surface-card p-5">
        <h3 className="mb-4 text-lg font-bold">Elenco Técnico</h3>
        <div className="grid grid-cols-1 gap-3 md:grid-cols-2 lg:grid-cols-3">
          {CREW.map((c) => (
            <div key={c.role} className="rounded-md border border-[var(--border-color)] bg-[var(--surface-2)] p-4">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-[10px] uppercase tracking-widest text-muted-foreground">{c.role}</div>
                  <div className="text-sm font-semibold">{c.name}</div>
                </div>
                <div className="text-mono text-xl font-black">{c.level}</div>
              </div>
              <div className="mt-3 h-1.5 w-full overflow-hidden rounded-full bg-[var(--surface-3)]">
                <div className="h-full brand-gradient" style={{ width: `${c.level}%` }} />
              </div>
            </div>
          ))}
        </div>
      </div>
    </AppLayout>
  );
}