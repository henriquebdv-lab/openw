import { createFileRoute } from "@tanstack/react-router";
import { AppLayout } from "@/components/AppLayout";
import { ClipboardList, Droplets, CircleDot } from "lucide-react";

export const Route = createFileRoute("/estrategia")({
  head: () => ({ meta: [{ title: "Estratégia — Open Wheel Strategy" }] }),
  component: Strategy,
});

const STINTS = [
  { stint: 1, laps: "1–22", tyre: "Médio", fuel: 42, note: "Ataque inicial" },
  { stint: 2, laps: "23–48", tyre: "Duro", fuel: 38, note: "Gerenciar desgaste" },
  { stint: 3, laps: "49–78", tyre: "Macio", fuel: 26, note: "Push final" },
];

function Strategy() {
  return (
    <AppLayout title="Plano de Corrida" subtitle="Estratégia • Mônaco">
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <div className="surface-card-elevated p-6 lg:col-span-2">
          <div className="flex items-center gap-2 text-[11px] uppercase tracking-widest text-muted-foreground">
            <ClipboardList className="h-3.5 w-3.5" /> Plano de Stints
          </div>
          <h2 className="mt-2 text-2xl font-black">Estratégia 2-Stops</h2>

          <div className="mt-6 space-y-4">
            {STINTS.map((s) => (
              <div key={s.stint} className="grid grid-cols-[auto_1fr_auto] items-center gap-4 rounded-md border border-[var(--border-color)] bg-[var(--surface-2)] p-4">
                <div className="brand-gradient grid h-10 w-10 place-items-center rounded-md text-mono font-black" style={{ color: "var(--brand-secondary)" }}>
                  {s.stint}
                </div>
                <div>
                  <div className="text-sm font-semibold">Voltas {s.laps} • Pneu {s.tyre}</div>
                  <div className="text-xs text-muted-foreground">{s.note}</div>
                </div>
                <div className="text-right">
                  <div className="text-[10px] uppercase tracking-widest text-muted-foreground">Combustível</div>
                  <div className="text-mono text-sm font-bold">{s.fuel}kg</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="space-y-4">
          <div className="surface-card p-5">
            <div className="flex items-center gap-2 text-[11px] uppercase tracking-widest text-muted-foreground">
              <CircleDot className="h-3.5 w-3.5" /> Alocação de Pneus
            </div>
            {[
              { name: "Macio", n: 2, color: "bg-rose-500" },
              { name: "Médio", n: 3, color: "bg-amber-400" },
              { name: "Duro", n: 2, color: "bg-white" },
            ].map((t) => (
              <div key={t.name} className="mt-3 flex items-center justify-between">
                <div className="flex items-center gap-2 text-sm">
                  <span className={`h-2.5 w-2.5 rounded-full ${t.color}`} />
                  {t.name}
                </div>
                <div className="text-mono text-sm font-semibold">{t.n} sets</div>
              </div>
            ))}
          </div>

          <div className="surface-card p-5">
            <div className="flex items-center gap-2 text-[11px] uppercase tracking-widest text-muted-foreground">
              <Droplets className="h-3.5 w-3.5" /> Combustível Total
            </div>
            <div className="text-mono mt-2 text-4xl font-black">106<span className="text-lg text-muted-foreground">kg</span></div>
            <div className="mt-3 h-2 w-full overflow-hidden rounded-full bg-[var(--surface-3)]">
              <div className="h-full brand-gradient" style={{ width: "88%" }} />
            </div>
            <div className="mt-2 text-xs text-muted-foreground">88% da capacidade permitida</div>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}