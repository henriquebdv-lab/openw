import { createFileRoute } from "@tanstack/react-router";
import { AppLayout } from "@/components/AppLayout";
import { Wrench, TrendingUp, FlaskConical, Cpu } from "lucide-react";

export const Route = createFileRoute("/desenvolvimento")({
  head: () => ({ meta: [{ title: "Desenvolvimento — Open Wheel Strategy" }] }),
  component: Dev,
});

const AREAS = [
  { name: "Aerodinâmica", value: 82, invest: 8, note: "Novo difusor em teste" },
  { name: "Motor", value: 71, invest: 6, note: "Mapa de queima otimizado" },
  { name: "Chassi", value: 64, invest: 4, note: "Rigidez torcional +3%" },
  { name: "Confiabilidade", value: 88, invest: 3, note: "Estável" },
  { name: "Eletrônica", value: 76, invest: 5, note: "ERS recalibrado" },
  { name: "Freios", value: 69, invest: 2, note: "Discos carbono novos" },
];

function Dev() {
  return (
    <AppLayout title="Desenvolvimento Técnico" subtitle="R&D">
      <div className="mb-6 grid grid-cols-2 gap-4 md:grid-cols-4">
        {[
          { icon: Wrench, label: "Projetos ativos", value: "6" },
          { icon: FlaskConical, label: "Em túnel de vento", value: "2" },
          { icon: Cpu, label: "Simulações/sem", value: "148" },
          { icon: TrendingUp, label: "Ganho por corrida", value: "+0.24s" },
        ].map((s) => (
          <div key={s.label} className="surface-card p-4">
            <s.icon className="h-4 w-4 text-[var(--brand-primary)]" />
            <div className="mt-2 text-[10px] uppercase tracking-widest text-muted-foreground">{s.label}</div>
            <div className="text-mono text-2xl font-black">{s.value}</div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        {AREAS.map((a) => (
          <div key={a.name} className="surface-card p-5">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-[11px] uppercase tracking-widest text-muted-foreground">Área</div>
                <div className="text-lg font-bold">{a.name}</div>
              </div>
              <div className="text-right">
                <div className="text-mono text-3xl font-black text-[var(--brand-primary)]">{a.value}</div>
                <div className="text-[10px] uppercase tracking-widest text-muted-foreground">Nível</div>
              </div>
            </div>
            <div className="mt-4 h-2 w-full overflow-hidden rounded-full bg-[var(--surface-3)]">
              <div className="h-full brand-gradient" style={{ width: `${a.value}%` }} />
            </div>
            <div className="mt-3 flex items-center justify-between text-xs">
              <span className="text-muted-foreground">{a.note}</span>
              <span className="text-mono rounded-md border border-[var(--border-color)] bg-[var(--surface-2)] px-2 py-0.5">
                Investimento: {a.invest} pts
              </span>
            </div>
          </div>
        ))}
      </div>
    </AppLayout>
  );
}