import { createFileRoute } from "@tanstack/react-router";
import { AppLayout } from "@/components/AppLayout";

export const Route = createFileRoute("/temporada")({
  head: () => ({ meta: [{ title: "Temporada — Open Wheel Strategy" }] }),
  component: Season,
});

const TIMELINE = [
  { gp: "Austrália", flag: "🇦🇺", status: "done" as const, pos: 4 },
  { gp: "Japão", flag: "🇯🇵", status: "done" as const, pos: 2 },
  { gp: "China", flag: "🇨🇳", status: "done" as const, pos: 6 },
  { gp: "Bahrein", flag: "🇧🇭", status: "done" as const, pos: 3 },
  { gp: "Espanha", flag: "🇪🇸", status: "done" as const, pos: 1 },
  { gp: "Itália", flag: "🇮🇹", status: "done" as const, pos: 5 },
  { gp: "Mônaco", flag: "🇲🇨", status: "current" as const },
  { gp: "Canadá", flag: "🇨🇦", status: "upcoming" as const },
  { gp: "Áustria", flag: "🇦🇹", status: "upcoming" as const },
  { gp: "Reino Unido", flag: "🇬🇧", status: "upcoming" as const },
  { gp: "Brasil", flag: "🇧🇷", status: "upcoming" as const },
];

function Season() {
  return (
    <AppLayout title="Temporada 2026" subtitle="Linha do tempo">
      <div className="mb-6 grid grid-cols-2 gap-4 md:grid-cols-4">
        <Stat label="Rodada atual" value="7 / 22" />
        <Stat label="Vitórias" value="1" />
        <Stat label="Pódios" value="3" />
        <Stat label="Pontos" value="248" primary />
      </div>

      <div className="surface-card p-6">
        <div className="text-[11px] uppercase tracking-widest text-muted-foreground">Calendário Visual</div>
        <h3 className="mt-1 text-lg font-bold">Progresso da Temporada</h3>

        <div className="mt-6 overflow-x-auto pb-2">
          <div className="flex min-w-max items-stretch gap-2">
            {TIMELINE.map((r, i) => {
              const done = r.status === "done";
              const current = r.status === "current";
              return (
                <div key={r.gp} className="flex items-center gap-2">
                  <div
                    className={`relative flex w-32 flex-col items-center rounded-lg border p-3 ${
                      current
                        ? "border-[var(--brand-primary)] bg-[color-mix(in_oklab,var(--brand-primary)_14%,var(--surface-2))] shadow-[0_0_0_1px_var(--brand-primary)]"
                        : done
                          ? "border-[var(--border-color)] bg-[var(--surface-2)]"
                          : "border-dashed border-[var(--border-color)] bg-transparent"
                    }`}
                  >
                    <div className="text-2xl">{r.flag}</div>
                    <div className="mt-1 truncate text-xs font-semibold">{r.gp}</div>
                    <div className="text-mono mt-1 text-[10px] uppercase tracking-widest text-muted-foreground">
                      {current ? "Atual" : done ? `P${r.pos}` : "Futura"}
                    </div>
                    {current && (
                      <span className="absolute -top-2 rounded-full brand-gradient px-2 py-0.5 text-[9px] font-bold uppercase tracking-widest" style={{ color: "var(--brand-secondary)" }}>
                        Live
                      </span>
                    )}
                  </div>
                  {i < TIMELINE.length - 1 && (
                    <div className={`h-0.5 w-6 ${done ? "brand-gradient" : "bg-[var(--surface-3)]"}`} />
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </AppLayout>
  );
}

function Stat({ label, value, primary }: { label: string; value: string; primary?: boolean }) {
  return (
    <div className="surface-card p-4">
      <div className="text-[10px] uppercase tracking-widest text-muted-foreground">{label}</div>
      <div className={`text-mono mt-1 text-3xl font-black ${primary ? "text-[var(--brand-primary)]" : ""}`}>{value}</div>
    </div>
  );
}