import { createFileRoute } from "@tanstack/react-router";
import { AppLayout } from "@/components/AppLayout";
import { Palette, Check } from "lucide-react";
import { THEME_PRESETS, useTheme } from "@/lib/theme";
import { useState } from "react";

export const Route = createFileRoute("/administracao")({
  head: () => ({ meta: [{ title: "Administração — Open Wheel Strategy" }] }),
  component: Admin,
});

function Admin() {
  const { primary, secondary, setColors, applyPreset } = useTheme();
  const [p, setP] = useState(primary);
  const [s, setS] = useState(secondary);

  return (
    <AppLayout title="Administração" subtitle="Identidade da Equipe">
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <div className="surface-card p-6 lg:col-span-2">
          <div className="flex items-center gap-2 text-[11px] uppercase tracking-widest text-muted-foreground">
            <Palette className="h-3.5 w-3.5" /> Paleta da Equipe
          </div>
          <h3 className="mt-1 text-lg font-bold">Temas rápidos</h3>
          <p className="text-sm text-muted-foreground">A interface adapta-se em tempo real à identidade escolhida.</p>

          <div className="mt-5 grid grid-cols-2 gap-3 md:grid-cols-3">
            {THEME_PRESETS.map((preset) => {
              const active = primary.toLowerCase() === preset.primary.toLowerCase();
              return (
                <button
                  key={preset.id}
                  onClick={() => {
                    applyPreset(preset.id);
                    setP(preset.primary);
                    setS(preset.secondary);
                  }}
                  className={`group relative overflow-hidden rounded-lg border p-4 text-left transition ${
                    active
                      ? "border-[var(--brand-primary)] shadow-[0_0_0_1px_var(--brand-primary)]"
                      : "border-[var(--border-color)] hover:border-[var(--border-strong)]"
                  }`}
                  style={{ background: "var(--surface-2)" }}
                >
                  <div className="flex items-center gap-2">
                    <div className="h-10 w-10 rounded-md" style={{ background: preset.primary }} />
                    <div className="h-10 w-6 rounded-md border border-[var(--border-color)]" style={{ background: preset.secondary }} />
                    {active && (
                      <span className="ml-auto grid h-6 w-6 place-items-center rounded-full brand-gradient" style={{ color: "var(--brand-secondary)" }}>
                        <Check className="h-3.5 w-3.5" />
                      </span>
                    )}
                  </div>
                  <div className="mt-3 font-semibold">{preset.name}</div>
                  <div className="text-mono text-xs text-muted-foreground">
                    {preset.primary} · {preset.secondary}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        <div className="surface-card p-6">
          <div className="text-[11px] uppercase tracking-widest text-muted-foreground">Personalizar</div>
          <h3 className="mt-1 text-lg font-bold">Cores da Equipe</h3>

          <label className="mt-5 block text-xs font-semibold text-muted-foreground">Cor Primária</label>
          <div className="mt-1.5 flex items-center gap-3">
            <input type="color" value={p} onChange={(e) => setP(e.target.value)} className="h-11 w-14 cursor-pointer rounded-md border border-[var(--border-color)] bg-transparent" />
            <input value={p} onChange={(e) => setP(e.target.value)} className="text-mono w-full rounded-md border border-[var(--border-color)] bg-[var(--surface-2)] px-3 py-2 text-sm" />
          </div>

          <label className="mt-4 block text-xs font-semibold text-muted-foreground">Cor Secundária</label>
          <div className="mt-1.5 flex items-center gap-3">
            <input type="color" value={s} onChange={(e) => setS(e.target.value)} className="h-11 w-14 cursor-pointer rounded-md border border-[var(--border-color)] bg-transparent" />
            <input value={s} onChange={(e) => setS(e.target.value)} className="text-mono w-full rounded-md border border-[var(--border-color)] bg-[var(--surface-2)] px-3 py-2 text-sm" />
          </div>

          <button onClick={() => setColors(p, s)} className="mt-6 w-full rounded-md brand-gradient px-4 py-2.5 text-sm font-bold" style={{ color: "var(--brand-secondary)" }}>
            Aplicar Identidade
          </button>

          <div className="mt-6 rounded-md border border-[var(--border-color)] bg-[var(--surface-2)] p-4">
            <div className="text-[10px] uppercase tracking-widest text-muted-foreground">Prévia</div>
            <div className="mt-2 flex items-center gap-3">
              <div className="brand-gradient grid h-10 w-10 place-items-center rounded-md font-black" style={{ color: "var(--brand-secondary)" }}>
                #1
              </div>
              <div>
                <div className="text-sm font-bold">Apex Racing</div>
                <div className="text-mono text-xs text-muted-foreground">Cor da equipe</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}