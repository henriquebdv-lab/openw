import { createFileRoute } from "@tanstack/react-router";
import { AppLayout } from "@/components/AppLayout";
import { Trophy, Medal } from "lucide-react";

export const Route = createFileRoute("/classificacao")({
  head: () => ({ meta: [{ title: "Classificação — Open Wheel Strategy" }] }),
  component: Standings,
});

const TEAMS = [
  { pos: 1, name: "Nordic Motorsport", pts: 342, delta: "+94", color: "#0066ff", self: false },
  { pos: 2, name: "Scuderia Falcone", pts: 290, delta: "+42", color: "#d00000", self: false },
  { pos: 3, name: "Apex Racing", pts: 248, delta: "—", color: "var(--brand-primary)", self: true },
  { pos: 4, name: "Meridian GP", pts: 201, delta: "-47", color: "#ff7a00", self: false },
  { pos: 5, name: "Helios Sports", pts: 176, delta: "-72", color: "#f5d000", self: false },
  { pos: 6, name: "Onyx Racing", pts: 142, delta: "-106", color: "#a0a0a0", self: false },
  { pos: 7, name: "Volante Squadra", pts: 118, delta: "-130", color: "#8b5cf6", self: false },
  { pos: 8, name: "Ignis Works", pts: 96, delta: "-152", color: "#10b981", self: false },
  { pos: 9, name: "Solaris Racing", pts: 62, delta: "-186", color: "#f472b6", self: false },
  { pos: 10, name: "Circuit Nine", pts: 38, delta: "-210", color: "#22d3ee", self: false },
];

function Standings() {
  const [p1, p2, p3, ...rest] = TEAMS;
  return (
    <AppLayout title="Classificação de Construtores" subtitle="Campeonato 2026">
      <div className="mb-8 grid grid-cols-1 gap-4 md:grid-cols-3">
        <PodiumCard team={p2} rank={2} icon={<Medal className="h-6 w-6" />} />
        <PodiumCard team={p1} rank={1} icon={<Trophy className="h-7 w-7" />} big />
        <PodiumCard team={p3} rank={3} icon={<Medal className="h-6 w-6" />} />
      </div>

      <div className="surface-card overflow-hidden">
        <div className="grid grid-cols-[auto_1fr_auto_auto] items-center gap-4 border-b border-[var(--border-color)] px-5 py-3 text-[10px] uppercase tracking-widest text-muted-foreground">
          <span>Pos</span><span>Equipe</span><span>Pontos</span><span>Gap</span>
        </div>
        {rest.map((t) => (
          <div
            key={t.pos}
            className={`grid grid-cols-[auto_1fr_auto_auto] items-center gap-4 border-b border-[var(--border-color)] px-5 py-4 last:border-0 ${
              t.self ? "bg-[color-mix(in_oklab,var(--brand-primary)_10%,transparent)]" : "hover:bg-[var(--surface-2)]"
            }`}
          >
            <span className="text-mono w-8 text-lg font-bold text-muted-foreground">{t.pos}</span>
            <div className="flex items-center gap-3">
              <span className="h-6 w-1 rounded-full" style={{ background: t.color }} />
              <span className="font-semibold">{t.name}</span>
            </div>
            <span className="text-mono font-bold">{t.pts}</span>
            <span className="text-mono text-xs text-muted-foreground">{t.delta}</span>
          </div>
        ))}
      </div>
    </AppLayout>
  );
}

function PodiumCard({
  team,
  rank,
  icon,
  big,
}: {
  team: (typeof TEAMS)[number];
  rank: 1 | 2 | 3;
  icon: React.ReactNode;
  big?: boolean;
}) {
  const glow = rank === 1 ? "shadow-[0_0_60px_-10px_var(--brand-primary)]" : "";
  return (
    <div
      className={`surface-card-elevated relative overflow-hidden p-6 text-center ${glow} ${
        big ? "md:-mt-4 md:pb-8" : ""
      }`}
    >
      {rank === 1 && <div className="absolute inset-x-0 top-0 h-1 brand-gradient" />}
      <div
        className="mx-auto grid place-items-center rounded-full"
        style={{
          width: big ? 72 : 60,
          height: big ? 72 : 60,
          background: rank === 1 ? "var(--brand-primary)" : "var(--surface-3)",
          color: rank === 1 ? "var(--brand-secondary)" : "var(--foreground)",
        }}
      >
        {icon}
      </div>
      <div className="text-mono mt-3 text-[10px] uppercase tracking-widest text-muted-foreground">
        {rank === 1 ? "1º • Líder" : rank === 2 ? "2º Lugar" : "3º Lugar"}
      </div>
      <div className={`mt-1 font-black ${big ? "text-2xl" : "text-xl"}`}>{team.name}</div>
      <div className="text-mono mt-2 text-3xl font-black text-[var(--brand-primary)]">{team.pts}</div>
      <div className="text-[10px] uppercase tracking-widest text-muted-foreground">pontos</div>

      <div className="mt-4 h-1 w-full rounded-full" style={{ background: team.color, opacity: 0.6 }} />
    </div>
  );
}