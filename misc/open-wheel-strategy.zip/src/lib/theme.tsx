import { createContext, useContext, useEffect, useState, type ReactNode } from "react";

export type ThemePreset = {
  id: string;
  name: string;
  primary: string;
  secondary: string;
};

export const THEME_PRESETS: ThemePreset[] = [
  { id: "red", name: "Escarlate", primary: "#d00000", secondary: "#ffffff" },
  { id: "blue", name: "Azul Elétrico", primary: "#0066ff", secondary: "#ffffff" },
  { id: "orange", name: "Laranja Ígneo", primary: "#ff7a00", secondary: "#111111" },
  { id: "silver", name: "Prata", primary: "#a0a0a0", secondary: "#202020" },
  { id: "green", name: "Verde Britânico", primary: "#00875a", secondary: "#ffffff" },
  { id: "yellow", name: "Amarelo Canário", primary: "#f5d000", secondary: "#111111" },
];

type ThemeCtx = {
  primary: string;
  secondary: string;
  setColors: (p: string, s: string) => void;
  applyPreset: (id: string) => void;
};

const Ctx = createContext<ThemeCtx | null>(null);
const STORAGE_KEY = "ows.theme.v1";

function apply(primary: string, secondary: string) {
  if (typeof document === "undefined") return;
  const root = document.documentElement;
  root.style.setProperty("--brand-primary", primary);
  root.style.setProperty("--brand-secondary", secondary);
}

export function ThemeProvider({ children }: { children: ReactNode }) {
  const [primary, setPrimary] = useState("#d00000");
  const [secondary, setSecondary] = useState("#ffffff");

  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const p = JSON.parse(raw);
        if (p.primary && p.secondary) {
          setPrimary(p.primary);
          setSecondary(p.secondary);
          apply(p.primary, p.secondary);
          return;
        }
      }
    } catch {}
    apply(primary, secondary);
     
  }, []);

  const setColors = (p: string, s: string) => {
    setPrimary(p);
    setSecondary(s);
    apply(p, s);
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify({ primary: p, secondary: s }));
    } catch {}
  };

  const applyPreset = (id: string) => {
    const preset = THEME_PRESETS.find((t) => t.id === id);
    if (preset) setColors(preset.primary, preset.secondary);
  };

  return <Ctx.Provider value={{ primary, secondary, setColors, applyPreset }}>{children}</Ctx.Provider>;
}

export function useTheme() {
  const c = useContext(Ctx);
  if (!c) throw new Error("useTheme must be inside ThemeProvider");
  return c;
}