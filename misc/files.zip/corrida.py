"""
Classe Corrida - simula vários carros ao mesmo tempo, volta a volta,
e calcula as posições de cada um a cada volta (o que gera as
"ultrapassagens" naturalmente, comparando tempo acumulado).
"""

from constantes import LIMITE_DESGASTE_PNEU, COMBUSTIVEL_MINIMO


class EstadoCarroNaCorrida:
    """Guarda o estado (combustível, desgaste) de um carro durante a corrida."""

    def __init__(self, carro):
        self.carro = carro
        self.combustivel = carro.combustivel_carregado
        self.desgaste_pneu = 0.0
        self.tempo_acumulado = 0.0
        self.pit_stops = 0
        self.historico_voltas = []  # uma entrada por volta

    def rodar_volta(self, numero_volta):
        tempo_volta = self.carro.tempo_com_variacao()

        self.combustivel -= self.carro.consumo_por_volta()
        self.desgaste_pneu += self.carro.desgaste_por_volta()

        pit_stop_nesta_volta = False
        if self.combustivel <= COMBUSTIVEL_MINIMO or self.desgaste_pneu >= LIMITE_DESGASTE_PNEU:
            tempo_volta += self.carro.tempo_pit_stop
            self.combustivel = self.carro.combustivel_carregado
            self.desgaste_pneu = 0.0
            self.pit_stops += 1
            pit_stop_nesta_volta = True

        self.tempo_acumulado += tempo_volta

        self.historico_voltas.append({
            "volta": numero_volta,
            "tempo_volta": round(tempo_volta, 3),
            "tempo_acumulado": round(self.tempo_acumulado, 3),
            "pit_stop": pit_stop_nesta_volta,
        })


class Corrida:
    def __init__(self, carros, total_voltas=60):
        """carros: lista de instâncias de Carro (um por piloto competindo)"""
        self.total_voltas = total_voltas
        self.estados = [EstadoCarroNaCorrida(carro) for carro in carros]

    def simular(self):
        """
        Roda a corrida inteira e devolve:
        - classificacao_final: lista ordenada do 1º ao último colocado
        - posicoes_por_volta: lista (uma por volta) com a ordem naquele momento
          (isso é o que alimenta o "replay" volta a volta)
        """
        posicoes_por_volta = []

        for volta in range(1, self.total_voltas + 1):
            for estado in self.estados:
                estado.rodar_volta(volta)

            posicoes_por_volta.append(self._ordem_atual())

        return {
            "classificacao_final": self._classificacao_final(),
            "posicoes_por_volta": posicoes_por_volta,
        }

    def _ordem_atual(self):
        ordenados = sorted(self.estados, key=lambda e: e.tempo_acumulado)
        tempo_lider = ordenados[0].tempo_acumulado if ordenados else 0.0
        return [
            {
                "equipe": e.carro.equipe.nome,
                "posicao": i + 1,
                "tempo_acumulado": e.tempo_acumulado,
                "diferenca_lider": e.tempo_acumulado - tempo_lider,
            }
            for i, e in enumerate(ordenados)
        ]

    def _classificacao_final(self):
        ordenados = sorted(self.estados, key=lambda e: e.tempo_acumulado)
        return [
            {
                "posicao": posicao,
                "equipe": e.carro.equipe.nome,
                "tempo_total_segundos": round(e.tempo_acumulado, 2),
                "pit_stops": e.pit_stops,
                "historico_voltas": e.historico_voltas,
            }
            for posicao, e in enumerate(ordenados, start=1)
        ]
