"""
Classe Carro - junta equipe + equipamentos (motor, combustível, pneu,
chassi) + opcionalmente designer de chassi e engenheiro (esses dois
são pessoas contratadas à parte, podem não existir ainda).
"""

import random

from constantes import (
    TEMPO_VOLTA_BASE_SEGUNDOS,
    VARIACAO_ALEATORIA_DESVIO_PADRAO,
    CONSUMO_BASE_MOTOR,
    BONUS_DESIGNER_ESCALA,
    PIT_STOP_SEGUNDOS,
)


class Carro:
    def __init__(self, equipe, motor, combustivel, pneu, chassi, cambio, suspensao,
                 designer_chassi=None, engenheiro=None, combustivel_carregado=110.0,
                 tempo_pit_stop=None):
        self.equipe = equipe
        self.motor = motor
        self.combustivel = combustivel
        self.pneu = pneu
        self.chassi = chassi
        self.cambio = cambio
        self.suspensao = suspensao
        self.designer_chassi = designer_chassi
        self.engenheiro = engenheiro
        self.combustivel_carregado = combustivel_carregado
        # Se não informado, usa o valor padrão fixo (compatibilidade/testes)
        self.tempo_pit_stop = tempo_pit_stop if tempo_pit_stop is not None else PIT_STOP_SEGUNDOS

    def potencia_efetiva_motor(self):
        """Potência do motor já somada ao bônus que o combustível dá."""
        return self.motor.potencia * (1 + self.combustivel.aumento_potencia_motor)

    def tempo_base(self):
        tempo = TEMPO_VOLTA_BASE_SEGUNDOS
        tempo -= self.potencia_efetiva_motor()
        tempo -= self.pneu.performance
        tempo -= self.chassi.performance
        tempo -= self.cambio.performance
        tempo -= self.suspensao.performance

        if self.designer_chassi:
            tempo -= self.designer_chassi.eficiencia_exata * BONUS_DESIGNER_ESCALA

        return tempo

    def tempo_com_variacao(self):
        variacao = random.gauss(0, VARIACAO_ALEATORIA_DESVIO_PADRAO)
        return self.tempo_base() + variacao

    def consumo_por_volta(self):
        eficiencia_total = min(self.motor.eficiencia_combustivel + self.combustivel.eficiencia, 0.9)
        consumo = CONSUMO_BASE_MOTOR * (1 - eficiencia_total)

        if self.engenheiro:
            consumo *= (1 - self.engenheiro.bonus_eficiencia)

        return consumo

    def desgaste_por_volta(self):
        desgaste = self.pneu.desgaste

        if self.engenheiro:
            desgaste *= (1 - self.engenheiro.bonus_eficiencia)

        return desgaste

    def __repr__(self):
        return f"Carro({self.equipe.nome}: {self.motor.nome}/{self.pneu.nome})"
