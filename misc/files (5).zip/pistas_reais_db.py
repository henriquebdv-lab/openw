"""
Banco de dados SEPARADO só pra pistas reais (dado de referência estático,
baseado no OpenStreetMap via TUMFTM racetrack-database, licença LGPL-3.0).

Fica num arquivo .db diferente do jogo.db principal, sem se misturar com
os dados dinâmicos do jogo (usuários, equipes, resultados).
"""

import sqlite3
import os

CAMINHO_BANCO = os.path.join(os.path.dirname(os.path.abspath(__file__)), "pistas_reais.db")

FONTE_PADRAO = "OpenStreetMap, via TUMFTM racetrack-database (licença LGPL-3.0)"


def obter_conexao():
    conexao = sqlite3.connect(CAMINHO_BANCO)
    conexao.row_factory = sqlite3.Row
    return conexao


def criar_banco():
    conexao = obter_conexao()
    conexao.execute("""
        CREATE TABLE IF NOT EXISTS pistas_reais (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL,
            pais TEXT NOT NULL,
            extensao_km REAL NOT NULL,
            caminho_svg TEXT NOT NULL,
            largura_viewbox INTEGER NOT NULL,
            altura_viewbox INTEGER NOT NULL,
            tempo_pit_stop_segundos REAL NOT NULL DEFAULT 20.0,
            fonte TEXT DEFAULT '""" + FONTE_PADRAO + """'
        )
    """)
    # Se o banco já existia de antes (sem essa coluna), adiciona sem apagar nada
    try:
        conexao.execute("ALTER TABLE pistas_reais ADD COLUMN tempo_pit_stop_segundos REAL NOT NULL DEFAULT 20.0")
    except sqlite3.OperationalError:
        pass  # coluna já existe
    conexao.commit()
    conexao.close()


def inserir_pista_real(nome, pais, extensao_km, caminho_svg, largura_viewbox, altura_viewbox, tempo_pit_stop_segundos=20.0):
    conexao = obter_conexao()
    conexao.execute(
        """INSERT INTO pistas_reais (nome, pais, extensao_km, caminho_svg, largura_viewbox, altura_viewbox, tempo_pit_stop_segundos)
           VALUES (?, ?, ?, ?, ?, ?, ?)""",
        (nome, pais, extensao_km, caminho_svg, largura_viewbox, altura_viewbox, tempo_pit_stop_segundos),
    )
    conexao.commit()
    conexao.close()


def calcular_numero_voltas(extensao_km, distancia_minima_km=290, distancia_maxima_km=320, maximo_voltas=79):
    """
    Calcula quantas voltas fazem a distância total da corrida ficar entre
    290km e 320km, respeitando o máximo de 79 voltas. Pistas muito curtas
    podem não conseguir chegar em 290km sem passar de 79 voltas - nesse
    caso, usa o máximo de voltas mesmo ficando abaixo da faixa ideal.
    """
    distancia_alvo = (distancia_minima_km + distancia_maxima_km) / 2
    voltas = max(1, min(round(distancia_alvo / extensao_km), maximo_voltas))
    distancia_total = voltas * extensao_km

    tentativas = 0
    while not (distancia_minima_km <= distancia_total <= distancia_maxima_km) and tentativas < 30:
        if distancia_total < distancia_minima_km and voltas < maximo_voltas:
            voltas += 1
        elif distancia_total > distancia_maxima_km and voltas > 1:
            voltas -= 1
        else:
            break
        distancia_total = voltas * extensao_km
        tentativas += 1

    return voltas, round(distancia_total, 2)


def listar_pistas_reais():
    conexao = obter_conexao()
    linhas = conexao.execute("SELECT * FROM pistas_reais ORDER BY nome").fetchall()
    conexao.close()
    return [dict(linha) for linha in linhas]


def obter_pista_real(pista_id):
    conexao = obter_conexao()
    linha = conexao.execute("SELECT * FROM pistas_reais WHERE id = ?", (pista_id,)).fetchone()
    conexao.close()
    return dict(linha) if linha else None
