"""
Classe Corrida - simula vários carros ao mesmo tempo, volta a volta,
e calcula as posições de cada um a cada volta (o que gera as
"ultrapassagens" naturalmente, comparando tempo acumulado).

Regra do pneu: se o desgaste passar do limite, o pneu ESTOURA e o carro
abandona a corrida (não é mais um pit stop automático suave - é
definitivo). Combustível zerado continua sendo um pit stop normal.
"""

from constantes import LIMITE_DESGASTE_PNEU, COMBUSTIVEL_MINIMO


class EstadoCarroNaCorrida:
    """Guarda o estado (combustível, desgaste) de um carro durante a corrida."""

    def __init__(self, carro):
        self.carro = carro
        self.combustivel = carro.combustivel_carregado
        self.desgaste_pneu = 0.0
        self.tempo_acumulado = 0.0
        self.pit_stops = 0
        self.abandonou = False
        self.volta_abandono = None
        self.historico_voltas = []  # uma entrada por volta

    def rodar_volta(self, numero_volta):
        if self.abandonou:
            return  # carro já abandonou, não roda mais voltas

        tempo_volta = self.carro.tempo_com_variacao()

        self.combustivel -= self.carro.consumo_por_volta()
        self.desgaste_pneu += self.carro.desgaste_por_volta()

        if self.desgaste_pneu >= LIMITE_DESGASTE_PNEU:
            # Pneu estourou - abandono definitivo, não é pit stop
            self.abandonou = True
            self.volta_abandono = numero_volta
            self.tempo_acumulado += tempo_volta

            self.historico_voltas.append({
                "volta": numero_volta,
                "tempo_volta": round(tempo_volta, 3),
                "tempo_acumulado": round(self.tempo_acumulado, 3),
                "pit_stop": False,
                "abandonou": True,
            })
            return

        pit_stop_nesta_volta = False
        if self.combustivel <= COMBUSTIVEL_MINIMO:
            tempo_volta += self.carro.tempo_pit_stop
            self.combustivel = self.carro.combustivel_carregado
            self.pit_stops += 1
            pit_stop_nesta_volta = True

        self.tempo_acumulado += tempo_volta

        self.historico_voltas.append({
            "volta": numero_volta,
            "tempo_volta": round(tempo_volta, 3),
            "tempo_acumulado": round(self.tempo_acumulado, 3),
            "pit_stop": pit_stop_nesta_volta,
            "abandonou": False,
        })


class Corrida:
    def __init__(self, carros, total_voltas=60):
        """carros: lista de instâncias de Carro (um por piloto competindo)"""
        self.total_voltas = total_voltas
        self.estados = [EstadoCarroNaCorrida(carro) for carro in carros]

    def simular(self):
        """
        Roda a corrida inteira e devolve:
        - classificacao_final: lista ordenada do 1º ao último colocado
          (quem abandonou fica depois de quem terminou, ordenado por
          quantas voltas conseguiu completar)
        - posicoes_por_volta: lista (uma por volta) com a ordem naquele momento
        """
        posicoes_por_volta = []

        for volta in range(1, self.total_voltas + 1):
            for estado in self.estados:
                estado.rodar_volta(volta)

            posicoes_por_volta.append(self._ordem_atual())

        return {
            "classificacao_final": self._classificacao_final(),
            "posicoes_por_volta": posicoes_por_volta,
        }

    def _chave_ordenacao(self, estado):
        """Quem não abandonou vem primeiro (por tempo); quem abandonou vem
        depois, ordenado por quem foi mais longe."""
        if estado.abandonou:
            return (1, -estado.volta_abandono)
        return (0, estado.tempo_acumulado)

    def _ordem_atual(self):
        ordenados = sorted(self.estados, key=self._chave_ordenacao)
        finalizados = [e for e in ordenados if not e.abandonou]
        tempo_lider = finalizados[0].tempo_acumulado if finalizados else 0.0

        resultado = []
        for i, e in enumerate(ordenados):
            if e.abandonou:
                diferenca_lider = None
                diferenca_frente = None
            else:
                diferenca_lider = e.tempo_acumulado - tempo_lider
                if i == 0:
                    diferenca_frente = 0.0
                else:
                    carro_da_frente = ordenados[i - 1]
                    diferenca_frente = (
                        e.tempo_acumulado - carro_da_frente.tempo_acumulado
                        if not carro_da_frente.abandonou else None
                    )

            resultado.append({
                "equipe": e.carro.equipe.nome,
                "posicao": i + 1,
                "tempo_acumulado": e.tempo_acumulado,
                "diferenca_lider": diferenca_lider,
                "diferenca_frente": diferenca_frente,
                "abandonou": e.abandonou,
            })
        return resultado

    def _classificacao_final(self):
        ordenados = sorted(self.estados, key=self._chave_ordenacao)
        return [
            {
                "posicao": posicao,
                "equipe": e.carro.equipe.nome,
                "tempo_total_segundos": round(e.tempo_acumulado, 2),
                "pit_stops": e.pit_stops,
                "abandonou": e.abandonou,
                "volta_abandono": e.volta_abandono,
                "historico_voltas": e.historico_voltas,
            }
            for posicao, e in enumerate(ordenados, start=1)
        ]
