"""
Tabelas do banco de dados.

- Fornecedores: cada um tem 2 custos (contratar por temporada, e montar
  no carro pra corrida). O desempenho de cada fornecedor NUNCA aparece
  pro jogador - só o admin vê/edita esses números.
- Usuario: cadastro/login dos jogadores.
- EquipeDB: pertence a um Usuario (1 equipe por usuário).
- Pista: as 50 pistas do jogo, com atributos escondidos e visíveis.
"""

from datetime import datetime

from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash

db = SQLAlchemy()


# ---------------------------------------------------------
# USUÁRIO (cadastro/login)
# ---------------------------------------------------------

class Usuario(db.Model):
    __tablename__ = "usuarios"

    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(150), unique=True, nullable=False)
    senha_hash = db.Column(db.String(255), nullable=True)   # nulo pra quem entra só pelo Google
    google_id = db.Column(db.String(255), unique=True, nullable=True)
    eh_admin = db.Column(db.Boolean, default=False)
    criado_em = db.Column(db.DateTime, default=datetime.utcnow)

    equipe = db.relationship("EquipeDB", backref="usuario", uselist=False)

    def definir_senha(self, senha):
        self.senha_hash = generate_password_hash(senha)

    def verificar_senha(self, senha):
        if not self.senha_hash:
            return False
        return check_password_hash(self.senha_hash, senha)


# ---------------------------------------------------------
# FORNECEDORES (gerenciados pelo admin - desempenho nunca visível ao jogador)
# ---------------------------------------------------------

class FornecedorMotor(db.Model):
    __tablename__ = "fornecedores_motor"

    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(100), nullable=False)
    custo_temporada = db.Column(db.Float, default=0.0)   # contratar pra temporada toda
    custo_montagem = db.Column(db.Float, default=0.0)     # montar no carro pra 1 corrida
    ativo = db.Column(db.Boolean, default=True)
    potencia = db.Column(db.Float, default=0.0)                # escondido do jogador
    eficiencia_combustivel = db.Column(db.Float, default=0.0)  # escondido do jogador


class FornecedorCombustivel(db.Model):
    __tablename__ = "fornecedores_combustivel"

    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(100), nullable=False)
    custo_temporada = db.Column(db.Float, default=0.0)
    custo_montagem = db.Column(db.Float, default=0.0)
    ativo = db.Column(db.Boolean, default=True)
    eficiencia = db.Column(db.Float, default=0.0)               # escondido do jogador
    aumento_potencia_motor = db.Column(db.Float, default=0.0)   # escondido do jogador


class FornecedorPneu(db.Model):
    __tablename__ = "fornecedores_pneu"

    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(100), nullable=False)
    custo_temporada = db.Column(db.Float, default=0.0)
    custo_montagem = db.Column(db.Float, default=0.0)
    ativo = db.Column(db.Boolean, default=True)
    performance = db.Column(db.Float, default=0.0)   # escondido do jogador
    desgaste = db.Column(db.Float, default=1.8)       # escondido do jogador


class FornecedorChassi(db.Model):
    __tablename__ = "fornecedores_chassi"

    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(100), nullable=False)
    custo_temporada = db.Column(db.Float, default=0.0)
    custo_montagem = db.Column(db.Float, default=0.0)
    ativo = db.Column(db.Boolean, default=True)
    performance = db.Column(db.Float, default=0.0)   # escondido do jogador


class FornecedorEngenheiro(db.Model):
    __tablename__ = "fornecedores_engenheiro"

    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(100), nullable=False)
    custo_temporada = db.Column(db.Float, default=0.0)
    custo_montagem = db.Column(db.Float, default=0.0)
    ativo = db.Column(db.Boolean, default=True)
    nivel = db.Column(db.Integer, default=1)   # ativa só depois da 1ª temporada


class FornecedorDesignerChassi(db.Model):
    __tablename__ = "fornecedores_designer_chassi"

    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(100), nullable=False)
    custo_temporada = db.Column(db.Float, default=0.0)
    custo_montagem = db.Column(db.Float, default=0.0)
    ativo = db.Column(db.Boolean, default=True)
    nivel = db.Column(db.Integer, default=1)              # escondido do jogador (só admin)
    eficiencia_exata = db.Column(db.Float, default=0.0)   # escondido do jogador


# ---------------------------------------------------------
# PISTAS
# ---------------------------------------------------------

# ---------------------------------------------------------
# EQUIPE (pertence a um usuário) e histórico de resultados
# ---------------------------------------------------------

class EquipeDB(db.Model):
    __tablename__ = "equipes"

    id = db.Column(db.Integer, primary_key=True)
    usuario_id = db.Column(db.Integer, db.ForeignKey("usuarios.id"), unique=True, nullable=False)
    nome = db.Column(db.String(100), nullable=False)
    orcamento = db.Column(db.Float, default=1_000_000.0)

    motor_fornecedor_id = db.Column(db.Integer, db.ForeignKey("fornecedores_motor.id"), nullable=False)
    combustivel_fornecedor_id = db.Column(db.Integer, db.ForeignKey("fornecedores_combustivel.id"), nullable=False)
    pneu_fornecedor_id = db.Column(db.Integer, db.ForeignKey("fornecedores_pneu.id"), nullable=False)
    chassi_fornecedor_id = db.Column(db.Integer, db.ForeignKey("fornecedores_chassi.id"), nullable=False)

    designer_chassi_fornecedor_id = db.Column(db.Integer, db.ForeignKey("fornecedores_designer_chassi.id"), nullable=True)
    engenheiro_fornecedor_id = db.Column(db.Integer, db.ForeignKey("fornecedores_engenheiro.id"), nullable=True)

    combustivel_carregado = db.Column(db.Float, default=110.0)

    cor_primaria = db.Column(db.String(7), default="#cc0000")
    cor_secundaria = db.Column(db.String(7), default="#ffffff")

    def montar_carro(self):
        """Constrói o objeto de domínio Carro a partir dos dados salvos."""
        from equipamentos import Motor, Combustivel, Pneu, Chassi, Engenheiro, DesignerChassi
        from equipe import Equipe
        from carro import Carro

        motor_db = FornecedorMotor.query.get(self.motor_fornecedor_id)
        combustivel_db = FornecedorCombustivel.query.get(self.combustivel_fornecedor_id)
        pneu_db = FornecedorPneu.query.get(self.pneu_fornecedor_id)
        chassi_db = FornecedorChassi.query.get(self.chassi_fornecedor_id)

        designer_db = (
            FornecedorDesignerChassi.query.get(self.designer_chassi_fornecedor_id)
            if self.designer_chassi_fornecedor_id else None
        )
        engenheiro_db = (
            FornecedorEngenheiro.query.get(self.engenheiro_fornecedor_id)
            if self.engenheiro_fornecedor_id else None
        )

        equipe = Equipe(self.nome, self.orcamento)
        motor = Motor(motor_db.nome, motor_db.custo_temporada, motor_db.potencia, motor_db.eficiencia_combustivel)
        combustivel = Combustivel(combustivel_db.nome, combustivel_db.custo_temporada, combustivel_db.eficiencia,
                                   combustivel_db.aumento_potencia_motor)
        pneu = Pneu(pneu_db.nome, pneu_db.custo_temporada, pneu_db.performance, pneu_db.desgaste)
        chassi = Chassi(chassi_db.nome, chassi_db.custo_temporada, chassi_db.performance)

        designer_chassi = (
            DesignerChassi(designer_db.nome, designer_db.custo_temporada, designer_db.nivel, designer_db.eficiencia_exata)
            if designer_db else None
        )
        engenheiro = (
            Engenheiro(engenheiro_db.nome, engenheiro_db.custo_temporada, engenheiro_db.nivel)
            if engenheiro_db else None
        )

        return Carro(
            equipe=equipe, motor=motor, combustivel=combustivel, pneu=pneu, chassi=chassi,
            designer_chassi=designer_chassi, engenheiro=engenheiro,
            combustivel_carregado=self.combustivel_carregado,
        )

    def custo_total_montagem(self):
        """Soma o custo de MONTAGEM (por corrida) de todos os itens escolhidos."""
        total = 0.0
        for modelo, campo_id in [
            (FornecedorMotor, self.motor_fornecedor_id),
            (FornecedorCombustivel, self.combustivel_fornecedor_id),
            (FornecedorPneu, self.pneu_fornecedor_id),
            (FornecedorChassi, self.chassi_fornecedor_id),
        ]:
            item = modelo.query.get(campo_id)
            if item:
                total += item.custo_montagem
        if self.designer_chassi_fornecedor_id:
            designer = FornecedorDesignerChassi.query.get(self.designer_chassi_fornecedor_id)
            if designer:
                total += designer.custo_montagem
        return total


class ResultadoClassificacao(db.Model):
    __tablename__ = "resultados_classificacao"

    id = db.Column(db.Integer, primary_key=True)
    equipe_id = db.Column(db.Integer, db.ForeignKey("equipes.id"), nullable=False)
    tempo_classificacao = db.Column(db.Float)
    posicao_grid = db.Column(db.Integer)
    criado_em = db.Column(db.DateTime, default=datetime.utcnow)

    equipe = db.relationship("EquipeDB")


class ResultadoCorrida(db.Model):
    __tablename__ = "resultados_corrida"

    id = db.Column(db.Integer, primary_key=True)
    equipe_id = db.Column(db.Integer, db.ForeignKey("equipes.id"), nullable=False)
    tempo_total_segundos = db.Column(db.Float)
    pit_stops = db.Column(db.Integer)
    posicao_final = db.Column(db.Integer)
    criado_em = db.Column(db.DateTime, default=datetime.utcnow)

    equipe = db.relationship("EquipeDB")
