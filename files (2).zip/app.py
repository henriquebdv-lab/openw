import functools
import click

from flask import Flask, render_template, request, redirect, url_for, session
from authlib.integrations.flask_client import OAuth

import config
from models import (
    db, Usuario, EquipeDB, ResultadoClassificacao, ResultadoCorrida,
    FornecedorMotor, FornecedorCombustivel, FornecedorPneu,
    FornecedorChassi, FornecedorCambio, FornecedorSuspensao,
    FornecedorEngenheiro,
    Configuracao, Desenvolvimento, TreinamentoBox,
)
from progressao import calcular_custo_proximo_avanco, calcular_tempo_proximo_avanco_horas, verificar_conclusao, avancar
from classificacao import Classificacao
from corrida import Corrida
from seed_fornecedores import popular_banco
from pistas_reais_db import criar_banco as criar_banco_pistas_reais, listar_pistas_reais

app = Flask(__name__)
app.config.from_object(config)
db.init_app(app)

oauth = OAuth(app)
google = oauth.register(
    name="google",
    client_id=app.config["GOOGLE_CLIENT_ID"],
    client_secret=app.config["GOOGLE_CLIENT_SECRET"],
    server_metadata_url="https://accounts.google.com/.well-known/openid-configuration",
    client_kwargs={"scope": "openid email profile"},
)


FORNECEDORES_CONFIG = {
    "motor": {
        "model": FornecedorMotor, "titulo": "Motor",
        "campos": [
            {"nome": "potencia", "label": "Potência", "tipo": "float"},
            {"nome": "eficiencia_combustivel", "label": "Eficiência de Combustível", "tipo": "float"},
        ],
    },
    "combustivel": {
        "model": FornecedorCombustivel, "titulo": "Combustível",
        "campos": [
            {"nome": "eficiencia", "label": "Eficiência", "tipo": "float"},
            {"nome": "aumento_potencia_motor", "label": "% Aumento Potência Motor", "tipo": "float"},
        ],
    },
    "pneu": {
        "model": FornecedorPneu, "titulo": "Pneu",
        "campos": [
            {"nome": "performance", "label": "Performance", "tipo": "float"},
            {"nome": "desgaste", "label": "Desgaste", "tipo": "float"},
        ],
    },
    "chassi": {
        "model": FornecedorChassi, "titulo": "Chassi",
        "campos": [{"nome": "performance", "label": "Performance", "tipo": "float"}],
    },
    "cambio": {
        "model": FornecedorCambio, "titulo": "Câmbio",
        "campos": [{"nome": "performance", "label": "Performance", "tipo": "float"}],
    },
    "suspensao": {
        "model": FornecedorSuspensao, "titulo": "Suspensão",
        "campos": [{"nome": "performance", "label": "Performance", "tipo": "float"}],
    },
    "engenheiro": {
        "model": FornecedorEngenheiro, "titulo": "Engenheiro",
        "campos": [
            {"nome": "nivel", "label": "Nível (jogador vê)", "tipo": "int"},
            {"nome": "eficiencia_exata", "label": "Eficiência exata (admin) - usada no Desenvolvimento", "tipo": "float"},
        ],
    },
}


@app.context_processor
def injetar_globais():
    usuario_id = session.get("usuario_id")
    usuario = Usuario.query.get(usuario_id) if usuario_id else None
    return {"usuario_logado": usuario, "categorias_fornecedor": FORNECEDORES_CONFIG}


def login_requerido(view_func):
    @functools.wraps(view_func)
    def wrapper(*args, **kwargs):
        if not session.get("usuario_id"):
            return redirect(url_for("login"))
        return view_func(*args, **kwargs)
    return wrapper


def admin_requerido(view_func):
    @functools.wraps(view_func)
    def wrapper(*args, **kwargs):
        usuario_id = session.get("usuario_id")
        if not usuario_id:
            return redirect(url_for("login"))
        usuario = Usuario.query.get(usuario_id)
        if not usuario or not usuario.eh_admin:
            return render_template("acesso_negado.html"), 403
        return view_func(*args, **kwargs)
    return wrapper


# ---------------------------------------------------------
# AUTENTICAÇÃO
# ---------------------------------------------------------

@app.route("/registrar", methods=["GET", "POST"])
def registrar():
    if request.method == "POST":
        email = request.form["email"].strip().lower()
        senha = request.form["senha"]

        if Usuario.query.filter_by(email=email).first():
            return render_template("registrar.html", erro="Esse e-mail já está cadastrado.")

        usuario = Usuario(email=email)
        usuario.definir_senha(senha)
        db.session.add(usuario)
        db.session.commit()

        session["usuario_id"] = usuario.id
        return redirect(url_for("minha_equipe"))

    return render_template("registrar.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form["email"].strip().lower()
        senha = request.form["senha"]
        usuario = Usuario.query.filter_by(email=email).first()

        if usuario and usuario.verificar_senha(senha):
            session["usuario_id"] = usuario.id
            return redirect(url_for("home"))

        return render_template("login.html", erro="E-mail ou senha inválidos.")

    return render_template("login.html")


@app.route("/login/google")
def login_google():
    redirect_uri = url_for("auth_google_callback", _external=True)
    return google.authorize_redirect(redirect_uri)


@app.route("/login/google/callback")
def auth_google_callback():
    token = google.authorize_access_token()
    userinfo = token.get("userinfo")

    email = userinfo["email"]
    google_id = userinfo["sub"]

    usuario = Usuario.query.filter_by(google_id=google_id).first()

    if not usuario:
        usuario = Usuario.query.filter_by(email=email).first()
        if usuario:
            usuario.google_id = google_id
        else:
            usuario = Usuario(email=email, google_id=google_id)
            db.session.add(usuario)

    db.session.commit()
    session["usuario_id"] = usuario.id
    return redirect(url_for("home"))


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("home"))


# ---------------------------------------------------------
# ROTAS DO JOGADOR
# ---------------------------------------------------------

@app.route("/")
def home():
    return render_template("home.html")


@app.route("/minha-equipe", methods=["GET", "POST"])
@login_requerido
def minha_equipe():
    usuario = Usuario.query.get(session["usuario_id"])

    if usuario.equipe:
        carro = usuario.equipe.montar_carro()
        return render_template(
            "minha_equipe.html", equipe=usuario.equipe, carro=carro,
            custo_montagem=usuario.equipe.custo_total_montagem(),
        )

    if request.method == "POST":
        engenheiro_id = request.form.get("engenheiro_fornecedor_id") or None
        nova_equipe = EquipeDB(
            usuario_id=usuario.id,
            nome=request.form["nome"],
            orcamento=float(request.form["orcamento"]),
            motor_fornecedor_id=int(request.form["motor_fornecedor_id"]),
            combustivel_fornecedor_id=int(request.form["combustivel_fornecedor_id"]),
            pneu_fornecedor_id=int(request.form["pneu_fornecedor_id"]),
            chassi_fornecedor_id=int(request.form["chassi_fornecedor_id"]),
            cambio_fornecedor_id=int(request.form["cambio_fornecedor_id"]),
            suspensao_fornecedor_id=int(request.form["suspensao_fornecedor_id"]),
            engenheiro_fornecedor_id=int(engenheiro_id) if engenheiro_id else None,
            combustivel_carregado=float(request.form["combustivel_carregado"]),
        )
        db.session.add(nova_equipe)
        db.session.commit()
        return redirect(url_for("minha_equipe"))

    return render_template(
        "equipes.html",
        motores=FornecedorMotor.query.filter_by(ativo=True).order_by(FornecedorMotor.custo_temporada).all(),
        combustiveis=FornecedorCombustivel.query.filter_by(ativo=True).order_by(FornecedorCombustivel.custo_temporada).all(),
        pneus=FornecedorPneu.query.filter_by(ativo=True).order_by(FornecedorPneu.custo_temporada).all(),
        chassis=FornecedorChassi.query.filter_by(ativo=True).order_by(FornecedorChassi.custo_temporada).all(),
        cambios=FornecedorCambio.query.filter_by(ativo=True).order_by(FornecedorCambio.custo_temporada).all(),
        suspensoes=FornecedorSuspensao.query.filter_by(ativo=True).order_by(FornecedorSuspensao.custo_temporada).all(),
        engenheiros=FornecedorEngenheiro.query.filter_by(ativo=True).order_by(FornecedorEngenheiro.custo_temporada).all(),
    )


@app.route("/minha-equipe/cores", methods=["GET", "POST"])
@login_requerido
def editar_cores():
    usuario = Usuario.query.get(session["usuario_id"])

    if not usuario.equipe:
        return redirect(url_for("minha_equipe"))

    if request.method == "POST":
        usuario.equipe.cor_primaria = request.form["cor_primaria"]
        usuario.equipe.cor_secundaria = request.form["cor_secundaria"]
        db.session.commit()
        return redirect(url_for("minha_equipe"))

    return render_template("editar_cores.html", equipe=usuario.equipe)


@app.route("/minha-equipe/desenvolvimento", methods=["GET", "POST"])
@login_requerido
def desenvolvimento_view():
    usuario = Usuario.query.get(session["usuario_id"])
    if not usuario.equipe:
        return redirect(url_for("minha_equipe"))

    equipe = usuario.equipe
    registro = Desenvolvimento.obter_ou_criar(equipe.id)
    config = Configuracao.obter()
    verificar_conclusao(registro, config.dev_incremento_percentual)

    mensagem = None
    if request.method == "POST":
        _, mensagem = avancar(
            registro, equipe, config.dev_custo_base, config.dev_custo_fator,
            config.dev_tempo_base_horas, config.dev_tempo_fator_horas,
            config.dev_incremento_percentual,
        )

    proximo_custo = calcular_custo_proximo_avanco(registro.percentual, config.dev_custo_base, config.dev_custo_fator)
    proximo_tempo = calcular_tempo_proximo_avanco_horas(registro.percentual, config.dev_tempo_base_horas, config.dev_tempo_fator_horas)

    return render_template(
        "desenvolvimento.html", equipe=equipe, registro=registro,
        proximo_custo=proximo_custo, proximo_tempo=proximo_tempo, mensagem=mensagem,
    )


@app.route("/minha-equipe/treinamento", methods=["GET", "POST"])
@login_requerido
def treinamento_view():
    usuario = Usuario.query.get(session["usuario_id"])
    if not usuario.equipe:
        return redirect(url_for("minha_equipe"))

    equipe = usuario.equipe
    registro = TreinamentoBox.obter_ou_criar(equipe.id)
    config = Configuracao.obter()
    verificar_conclusao(registro, config.treino_incremento_percentual)

    mensagem = None
    if request.method == "POST":
        _, mensagem = avancar(
            registro, equipe, config.treino_custo_base, config.treino_custo_fator,
            config.treino_tempo_base_horas, config.treino_tempo_fator_horas,
            config.treino_incremento_percentual,
        )

    proximo_custo = calcular_custo_proximo_avanco(registro.percentual, config.treino_custo_base, config.treino_custo_fator)
    proximo_tempo = calcular_tempo_proximo_avanco_horas(registro.percentual, config.treino_tempo_base_horas, config.treino_tempo_fator_horas)

    tempo_pit_atual = config.pit_tempo_sem_treino - (
        (config.pit_tempo_sem_treino - config.pit_tempo_treino_completo) * (registro.percentual / 100)
    )

    return render_template(
        "treinamento.html", equipe=equipe, registro=registro,
        proximo_custo=proximo_custo, proximo_tempo=proximo_tempo, mensagem=mensagem,
        tempo_pit_atual=round(tempo_pit_atual, 1),
    )


@app.route("/pistas-reais")
def pistas_reais_view():
    criar_banco_pistas_reais()
    pistas = listar_pistas_reais()
    return render_template("pistas_reais.html", pistas=pistas)


@app.route("/classificacao", methods=["GET", "POST"])
@login_requerido
def classificacao_view():
    resultado = None

    if request.method == "POST":
        usuario = Usuario.query.get(session["usuario_id"])
        if not usuario.eh_admin:
            return render_template("acesso_negado.html"), 403

        todas_equipes = EquipeDB.query.all()
        carros = [equipe_db.montar_carro() for equipe_db in todas_equipes]
        grid = Classificacao(carros).gerar_grid_largada()

        for posicao_info, equipe_db in zip(grid, todas_equipes):
            db.session.add(ResultadoClassificacao(
                equipe_id=equipe_db.id,
                tempo_classificacao=posicao_info["tempo_classificacao"],
                posicao_grid=posicao_info["posicao_grid"],
            ))
        db.session.commit()
        resultado = grid

    return render_template("classificacao.html", resultado=resultado)


@app.route("/corrida", methods=["GET", "POST"])
@login_requerido
def corrida_view():
    resultado = None

    if request.method == "POST":
        usuario = Usuario.query.get(session["usuario_id"])
        if not usuario.eh_admin:
            return render_template("acesso_negado.html"), 403

        total_voltas = int(request.form.get("total_voltas", 60))
        todas_equipes = EquipeDB.query.all()
        carros = [equipe_db.montar_carro() for equipe_db in todas_equipes]
        resultado = Corrida(carros, total_voltas=total_voltas).simular()

        equipes_por_nome = {e.nome: e for e in todas_equipes}
        for posicao_info in resultado["classificacao_final"]:
            equipe_db = equipes_por_nome[posicao_info["equipe"]]
            db.session.add(ResultadoCorrida(
                equipe_id=equipe_db.id,
                tempo_total_segundos=posicao_info["tempo_total_segundos"],
                pit_stops=posicao_info["pit_stops"],
                posicao_final=posicao_info["posicao"],
            ))
        db.session.commit()

    return render_template("corrida.html", resultado=resultado)


# ---------------------------------------------------------
# ROTAS DO ADMIN
# ---------------------------------------------------------

@app.route("/admin")
@admin_requerido
def admin_dashboard():
    contagens = {chave: cfg["model"].query.count() for chave, cfg in FORNECEDORES_CONFIG.items()}
    return render_template("admin_dashboard.html", categorias=FORNECEDORES_CONFIG, contagens=contagens)


@app.route("/admin/gerar-fornecedores", methods=["POST"])
@admin_requerido
def admin_gerar_fornecedores():
    popular_banco()
    return redirect(url_for("admin_dashboard"))


@app.route("/admin/fornecedores/<categoria>", methods=["GET", "POST"])
@admin_requerido
def admin_fornecedores(categoria):
    cfg = FORNECEDORES_CONFIG[categoria]
    Model = cfg["model"]

    if request.method == "POST":
        dados = {
            "nome": request.form["nome"],
            "custo_temporada": float(request.form["custo_temporada"]),
            "custo_montagem": float(request.form["custo_montagem"]),
            "ativo": True,
        }
        for campo in cfg["campos"]:
            valor = request.form[campo["nome"]]
            dados[campo["nome"]] = int(valor) if campo["tipo"] == "int" else float(valor)
        db.session.add(Model(**dados))
        db.session.commit()
        return redirect(url_for("admin_fornecedores", categoria=categoria))

    pagina = int(request.args.get("pagina", 1))
    por_pagina = 50
    total = Model.query.count()
    itens = Model.query.order_by(Model.custo_temporada).offset((pagina - 1) * por_pagina).limit(por_pagina).all()
    total_paginas = max(1, (total + por_pagina - 1) // por_pagina)

    return render_template(
        "admin_fornecedor_lista.html", categoria=categoria, cfg=cfg, itens=itens,
        pagina=pagina, total_paginas=total_paginas, total=total,
    )


@app.route("/admin/fornecedores/<categoria>/<int:item_id>/editar", methods=["GET", "POST"])
@admin_requerido
def admin_fornecedor_editar(categoria, item_id):
    cfg = FORNECEDORES_CONFIG[categoria]
    Model = cfg["model"]
    item = Model.query.get_or_404(item_id)

    if request.method == "POST":
        item.nome = request.form["nome"]
        item.custo_temporada = float(request.form["custo_temporada"])
        item.custo_montagem = float(request.form["custo_montagem"])
        item.ativo = "ativo" in request.form
        for campo in cfg["campos"]:
            valor = request.form[campo["nome"]]
            setattr(item, campo["nome"], int(valor) if campo["tipo"] == "int" else float(valor))
        db.session.commit()
        return redirect(url_for("admin_fornecedores", categoria=categoria))

    return render_template("admin_fornecedor_editar.html", categoria=categoria, cfg=cfg, item=item)


# ---------------------------------------------------------
# COMANDOS DE LINHA DE COMANDO
# ---------------------------------------------------------

@app.route("/admin/configuracoes", methods=["GET", "POST"])
@admin_requerido
def admin_configuracoes():
    config = Configuracao.obter()

    if request.method == "POST":
        campos_float = [
            "dev_incremento_percentual", "dev_tempo_base_horas", "dev_tempo_fator_horas",
            "dev_custo_base", "dev_custo_fator",
            "treino_incremento_percentual", "treino_tempo_base_horas", "treino_tempo_fator_horas",
            "treino_custo_base", "treino_custo_fator",
            "pit_tempo_sem_treino", "pit_tempo_treino_completo",
        ]
        for campo in campos_float:
            setattr(config, campo, float(request.form[campo]))
        db.session.commit()
        return redirect(url_for("admin_configuracoes"))

    return render_template("admin_configuracoes.html", config=config)


@app.cli.command("init-db")
def init_db():
    db.create_all()
    print("Banco inicializado!")


@app.cli.command("tornar-admin")
@click.argument("email")
def tornar_admin(email):
    """Promove um usuário existente a admin. Rode com: flask --app app tornar-admin seu@email.com"""
    usuario = Usuario.query.filter_by(email=email.strip().lower()).first()
    if not usuario:
        print(f"Nenhum usuário encontrado com o e-mail {email}. Cadastre-se primeiro pelo /registrar.")
        return
    usuario.eh_admin = True
    db.session.commit()
    print(f"{email} agora é admin!")


if __name__ == "__main__":
    app.run(debug=True)
