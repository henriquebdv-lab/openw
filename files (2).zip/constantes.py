"""
Todas as constantes de regras do jogo, num lugar só (DRY: se um número
precisa mudar, muda aqui e só aqui).
"""

TEMPO_VOLTA_BASE_SEGUNDOS = 90.0
PIT_STOP_SEGUNDOS = 22.0
LIMITE_DESGASTE_PNEU = 100.0
COMBUSTIVEL_MINIMO = 0.0
VARIACAO_ALEATORIA_DESVIO_PADRAO = 0.15  # segundos - "ruído" natural de cada volta
CONSUMO_BASE_MOTOR = 3.0        # litros/volta antes de aplicar eficiências
BONUS_DESIGNER_ESCALA = 5.0     # multiplica a eficiência exata do engenheiro no desenvolvimento (em segundos)
