"""
Gera fornecedores fictícios pra cada categoria (500 de cada, por padrão).

Os números são gerados dentro de faixas realistas e o custo é
correlacionado com a qualidade do item (melhor status = mais caro,
com uma variação aleatória por cima pra não ficar tudo "na régua").
"""

import random

from models import (
    db, FornecedorMotor, FornecedorCombustivel, FornecedorPneu,
    FornecedorChassi, FornecedorCambio, FornecedorSuspensao,
    FornecedorEngenheiro,
)

QUANTIDADE_PADRAO = 500

# ---------------------------------------------------------
# Geração de nomes fictícios
# ---------------------------------------------------------

PREFIXOS_MOTOR = ["Turbo", "Power", "Apex", "Vortex", "Blaze", "Thunder", "Nitro", "Quantum", "Titan", "Volt"]
SUFIXOS_MOTOR = ["Dynamics", "Racing", "Motors", "Systems", "Engineering", "Works", "Labs", "Tech", "Drive", "Force"]

PREFIXOS_COMBUSTIVEL = ["Race", "Eco", "Max", "Pure", "Turbo", "Bio", "Ultra", "Prime", "Fusion", "Nitro"]
SUFIXOS_COMBUSTIVEL = ["Fuel", "Gas", "Energy", "Petro", "Combust", "Blend", "Oil", "Fluid"]

PREFIXOS_PNEU = ["Grip", "Road", "Track", "Speed", "Terra", "Roca", "Vector", "Prime", "Ultra", "Ace"]
SUFIXOS_PNEU = ["Tire", "Tread", "Rubber", "Compound", "Traction", "Wheels"]

PREFIXOS_CHASSI = ["Aero", "Carbon", "Light", "Rigid", "Dynamic", "Precision", "Flex", "Steel", "Alloy", "Nano"]
SUFIXOS_CHASSI = ["Chassis", "Frame", "Structures", "Composites", "Build"]

PREFIXOS_CAMBIO = ["Shift", "Gear", "Quick", "Preciso", "Rapid", "Smooth", "Direct", "Instant", "Sync", "Flow"]
SUFIXOS_CAMBIO = ["Shift", "Trans", "Box", "Drive", "Gears", "System"]

PREFIXOS_SUSPENSAO = ["Stable", "Firm", "Adaptive", "Dynamic", "Balance", "Grip", "Smooth", "Active", "Tuned", "Rigid"]
SUFIXOS_SUSPENSAO = ["Susp", "Ride", "Dampers", "Control", "Tech"]

NOMES_PESSOA = ["Ricardo", "Marcos", "Felipe", "André", "Bruno", "Carlos", "Diego", "Eduardo",
                "Gabriel", "Henrique", "Igor", "Lucas", "Mateus", "Nelson", "Otávio", "Paulo",
                "Rafael", "Sérgio", "Thiago", "Vitor"]
SOBRENOMES_PESSOA = ["Silva", "Santos", "Oliveira", "Souza", "Costa", "Pereira", "Ferreira",
                     "Almeida", "Barbosa", "Ribeiro", "Martins", "Carvalho", "Rocha", "Dias",
                     "Nunes", "Teixeira", "Mendes", "Freitas", "Cavalcanti", "Araújo"]


def gerar_nome_item(prefixos, sufixos, indice):
    return f"{random.choice(prefixos)}{random.choice(sufixos)} #{indice}"


def gerar_nome_pessoa(indice):
    return f"{random.choice(NOMES_PESSOA)} {random.choice(SOBRENOMES_PESSOA)} #{indice}"


# ---------------------------------------------------------
# Geração de cada categoria
# ---------------------------------------------------------

def gerar_motores(quantidade):
    motores = []
    for i in range(1, quantidade + 1):
        potencia = round(random.uniform(0.0, 3.0), 2)
        eficiencia = round(random.uniform(0.0, 0.5), 3)
        qualidade = (potencia / 3.0) + (eficiencia / 0.5)
        custo_temporada = max(0, round((qualidade / 2) * 800_000 + random.uniform(-50_000, 50_000), -3))
        custo_montagem = max(0, round(custo_temporada * random.uniform(0.05, 0.15), -2))

        motores.append(FornecedorMotor(
            nome=gerar_nome_item(PREFIXOS_MOTOR, SUFIXOS_MOTOR, i),
            custo_temporada=custo_temporada, custo_montagem=custo_montagem,
            potencia=potencia, eficiencia_combustivel=eficiencia, ativo=True,
        ))
    return motores


def gerar_combustiveis(quantidade):
    combustiveis = []
    for i in range(1, quantidade + 1):
        eficiencia = round(random.uniform(0.0, 0.3), 3)
        aumento_potencia = round(random.uniform(0.0, 0.25), 3)
        qualidade = (eficiencia / 0.3) + (aumento_potencia / 0.25)
        custo_temporada = max(0, round((qualidade / 2) * 400_000 + random.uniform(-20_000, 20_000), -3))
        custo_montagem = max(0, round(custo_temporada * random.uniform(0.05, 0.15), -2))

        combustiveis.append(FornecedorCombustivel(
            nome=gerar_nome_item(PREFIXOS_COMBUSTIVEL, SUFIXOS_COMBUSTIVEL, i),
            custo_temporada=custo_temporada, custo_montagem=custo_montagem,
            eficiencia=eficiencia, aumento_potencia_motor=aumento_potencia, ativo=True,
        ))
    return combustiveis


def gerar_pneus(quantidade):
    pneus = []
    for i in range(1, quantidade + 1):
        performance = round(random.uniform(-0.5, 2.0), 2)
        desgaste = round(random.uniform(0.8, 3.0), 2)
        qualidade = (performance / 2.0) - (desgaste - 0.8) / 2.2 * 0.5
        custo_temporada = max(0, round(qualidade * 350_000 + random.uniform(-20_000, 20_000), -3))
        custo_montagem = max(0, round(custo_temporada * random.uniform(0.05, 0.15), -2))

        pneus.append(FornecedorPneu(
            nome=gerar_nome_item(PREFIXOS_PNEU, SUFIXOS_PNEU, i),
            custo_temporada=custo_temporada, custo_montagem=custo_montagem,
            performance=performance, desgaste=desgaste, ativo=True,
        ))
    return pneus


def gerar_chassis(quantidade):
    chassis = []
    for i in range(1, quantidade + 1):
        performance = round(random.uniform(0.0, 2.0), 2)
        custo_temporada = max(0, round((performance / 2.0) * 700_000 + random.uniform(-30_000, 30_000), -3))
        custo_montagem = max(0, round(custo_temporada * random.uniform(0.05, 0.15), -2))

        chassis.append(FornecedorChassi(
            nome=gerar_nome_item(PREFIXOS_CHASSI, SUFIXOS_CHASSI, i),
            custo_temporada=custo_temporada, custo_montagem=custo_montagem,
            performance=performance, ativo=True,
        ))
    return chassis


def gerar_cambios(quantidade):
    cambios = []
    for i in range(1, quantidade + 1):
        performance = round(random.uniform(0.0, 1.5), 2)
        custo_temporada = max(0, round((performance / 1.5) * 500_000 + random.uniform(-25_000, 25_000), -3))
        custo_montagem = max(0, round(custo_temporada * random.uniform(0.05, 0.15), -2))

        cambios.append(FornecedorCambio(
            nome=gerar_nome_item(PREFIXOS_CAMBIO, SUFIXOS_CAMBIO, i),
            custo_temporada=custo_temporada, custo_montagem=custo_montagem,
            performance=performance, ativo=True,
        ))
    return cambios


def gerar_suspensoes(quantidade):
    suspensoes = []
    for i in range(1, quantidade + 1):
        performance = round(random.uniform(0.0, 1.5), 2)
        custo_temporada = max(0, round((performance / 1.5) * 500_000 + random.uniform(-25_000, 25_000), -3))
        custo_montagem = max(0, round(custo_temporada * random.uniform(0.05, 0.15), -2))

        suspensoes.append(FornecedorSuspensao(
            nome=gerar_nome_item(PREFIXOS_SUSPENSAO, SUFIXOS_SUSPENSAO, i),
            custo_temporada=custo_temporada, custo_montagem=custo_montagem,
            performance=performance, ativo=True,
        ))
    return suspensoes


def gerar_engenheiros(quantidade):
    engenheiros = []
    for i in range(1, quantidade + 1):
        nivel = random.choices([1, 2, 3, 4, 5], weights=[30, 25, 20, 15, 10])[0]
        faixa_inicio = (nivel - 1) * 0.04
        eficiencia_exata = round(random.uniform(faixa_inicio, faixa_inicio + 0.04), 4)
        custo_temporada = max(0, nivel * 180_000 + random.randint(-20_000, 20_000))
        custo_montagem = max(0, round(custo_temporada * random.uniform(0.05, 0.15), -2))

        engenheiros.append(FornecedorEngenheiro(
            nome=gerar_nome_pessoa(i), custo_temporada=custo_temporada, custo_montagem=custo_montagem,
            nivel=nivel, eficiencia_exata=eficiencia_exata, ativo=True,
        ))
    return engenheiros


def popular_banco(quantidade=QUANTIDADE_PADRAO, limpar_antes=True):
    """Gera e salva os fornecedores fictícios de todas as categorias."""
    if limpar_antes:
        FornecedorMotor.query.delete()
        FornecedorCombustivel.query.delete()
        FornecedorPneu.query.delete()
        FornecedorChassi.query.delete()
        FornecedorCambio.query.delete()
        FornecedorSuspensao.query.delete()
        FornecedorEngenheiro.query.delete()

    db.session.bulk_save_objects(gerar_motores(quantidade))
    db.session.bulk_save_objects(gerar_combustiveis(quantidade))
    db.session.bulk_save_objects(gerar_pneus(quantidade))
    db.session.bulk_save_objects(gerar_chassis(quantidade))
    db.session.bulk_save_objects(gerar_cambios(quantidade))
    db.session.bulk_save_objects(gerar_suspensoes(quantidade))
    db.session.bulk_save_objects(gerar_engenheiros(quantidade))
    db.session.commit()
