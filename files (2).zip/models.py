"""
Tabelas do banco de dados.

- Fornecedores: cada um tem 2 custos (contratar por temporada, e montar
  no carro pra corrida). O desempenho de cada fornecedor NUNCA aparece
  pro jogador - só o admin vê/edita esses números.
- Usuario: cadastro/login dos jogadores.
- EquipeDB: pertence a um Usuario (1 equipe por usuário).
- Pista: as 50 pistas do jogo, com atributos escondidos e visíveis.
"""

from datetime import datetime

from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash

db = SQLAlchemy()


# ---------------------------------------------------------
# USUÁRIO (cadastro/login)
# ---------------------------------------------------------

class Usuario(db.Model):
    __tablename__ = "usuarios"

    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(150), unique=True, nullable=False)
    senha_hash = db.Column(db.String(255), nullable=True)   # nulo pra quem entra só pelo Google
    google_id = db.Column(db.String(255), unique=True, nullable=True)
    eh_admin = db.Column(db.Boolean, default=False)
    criado_em = db.Column(db.DateTime, default=datetime.utcnow)

    equipe = db.relationship("EquipeDB", backref="usuario", uselist=False)

    def definir_senha(self, senha):
        self.senha_hash = generate_password_hash(senha)

    def verificar_senha(self, senha):
        if not self.senha_hash:
            return False
        return check_password_hash(self.senha_hash, senha)


# ---------------------------------------------------------
# FORNECEDORES (gerenciados pelo admin - desempenho nunca visível ao jogador)
# ---------------------------------------------------------

class FornecedorMotor(db.Model):
    __tablename__ = "fornecedores_motor"

    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(100), nullable=False)
    custo_temporada = db.Column(db.Float, default=0.0)   # contratar pra temporada toda
    custo_montagem = db.Column(db.Float, default=0.0)     # montar no carro pra 1 corrida
    ativo = db.Column(db.Boolean, default=True)
    potencia = db.Column(db.Float, default=0.0)                # escondido do jogador
    eficiencia_combustivel = db.Column(db.Float, default=0.0)  # escondido do jogador


class FornecedorCombustivel(db.Model):
    __tablename__ = "fornecedores_combustivel"

    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(100), nullable=False)
    custo_temporada = db.Column(db.Float, default=0.0)
    custo_montagem = db.Column(db.Float, default=0.0)
    ativo = db.Column(db.Boolean, default=True)
    eficiencia = db.Column(db.Float, default=0.0)               # escondido do jogador
    aumento_potencia_motor = db.Column(db.Float, default=0.0)   # escondido do jogador


class FornecedorPneu(db.Model):
    __tablename__ = "fornecedores_pneu"

    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(100), nullable=False)
    custo_temporada = db.Column(db.Float, default=0.0)
    custo_montagem = db.Column(db.Float, default=0.0)
    ativo = db.Column(db.Boolean, default=True)
    performance = db.Column(db.Float, default=0.0)   # escondido do jogador
    desgaste = db.Column(db.Float, default=1.8)       # escondido do jogador


class FornecedorChassi(db.Model):
    __tablename__ = "fornecedores_chassi"

    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(100), nullable=False)
    custo_temporada = db.Column(db.Float, default=0.0)
    custo_montagem = db.Column(db.Float, default=0.0)
    ativo = db.Column(db.Boolean, default=True)
    performance = db.Column(db.Float, default=0.0)   # escondido do jogador


class FornecedorCambio(db.Model):
    __tablename__ = "fornecedores_cambio"

    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(100), nullable=False)
    custo_temporada = db.Column(db.Float, default=0.0)
    custo_montagem = db.Column(db.Float, default=0.0)
    ativo = db.Column(db.Boolean, default=True)
    performance = db.Column(db.Float, default=0.0)   # escondido do jogador


class FornecedorSuspensao(db.Model):
    __tablename__ = "fornecedores_suspensao"

    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(100), nullable=False)
    custo_temporada = db.Column(db.Float, default=0.0)
    custo_montagem = db.Column(db.Float, default=0.0)
    ativo = db.Column(db.Boolean, default=True)
    performance = db.Column(db.Float, default=0.0)   # escondido do jogador


class FornecedorEngenheiro(db.Model):
    __tablename__ = "fornecedores_engenheiro"

    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(100), nullable=False)
    custo_temporada = db.Column(db.Float, default=0.0)
    custo_montagem = db.Column(db.Float, default=0.0)
    ativo = db.Column(db.Boolean, default=True)
    nivel = db.Column(db.Integer, default=1)                # visível ao jogador
    eficiencia_exata = db.Column(db.Float, default=0.0)      # escondido do jogador - usado no Desenvolvimento


# ---------------------------------------------------------
# PISTAS
# ---------------------------------------------------------

class Configuracao(db.Model):
    """
    Linha única (singleton) com os parâmetros do jogo que o admin pode
    ajustar sem mexer no código: tempo/custo de desenvolvimento e
    tempo de pit stop com/sem treinamento.
    """
    __tablename__ = "configuracao"

    id = db.Column(db.Integer, primary_key=True)

    # Desenvolvimento (chassi/aerodinâmica via Engenheiro)
    dev_incremento_percentual = db.Column(db.Float, default=5.0)
    dev_tempo_base_horas = db.Column(db.Float, default=1.0)
    dev_tempo_fator_horas = db.Column(db.Float, default=10.0)
    dev_custo_base = db.Column(db.Float, default=50_000.0)
    dev_custo_fator = db.Column(db.Float, default=1.0)

    # Treinamento de box (pit stop)
    treino_incremento_percentual = db.Column(db.Float, default=5.0)
    treino_tempo_base_horas = db.Column(db.Float, default=1.0)
    treino_tempo_fator_horas = db.Column(db.Float, default=6.0)
    treino_custo_base = db.Column(db.Float, default=30_000.0)
    treino_custo_fator = db.Column(db.Float, default=1.0)
    pit_tempo_sem_treino = db.Column(db.Float, default=25.0)
    pit_tempo_treino_completo = db.Column(db.Float, default=9.0)

    @classmethod
    def obter(cls):
        config = cls.query.get(1)
        if not config:
            config = cls(id=1)
            db.session.add(config)
            db.session.commit()
        return config


class Desenvolvimento(db.Model):
    """Progresso de desenvolvimento (chassi/aero) de uma equipe, 0-100%."""
    __tablename__ = "desenvolvimentos"

    id = db.Column(db.Integer, primary_key=True)
    equipe_id = db.Column(db.Integer, db.ForeignKey("equipes.id"), unique=True, nullable=False)
    percentual = db.Column(db.Float, default=0.0)
    em_progresso = db.Column(db.Boolean, default=False)
    inicio_em = db.Column(db.DateTime, nullable=True)
    horario_conclusao = db.Column(db.DateTime, nullable=True)

    @classmethod
    def obter_ou_criar(cls, equipe_id):
        registro = cls.query.filter_by(equipe_id=equipe_id).first()
        if not registro:
            registro = cls(equipe_id=equipe_id)
            db.session.add(registro)
            db.session.commit()
        return registro


class TreinamentoBox(db.Model):
    """Progresso de treinamento de box/mecânicos de uma equipe, 0-100%."""
    __tablename__ = "treinamentos_box"

    id = db.Column(db.Integer, primary_key=True)
    equipe_id = db.Column(db.Integer, db.ForeignKey("equipes.id"), unique=True, nullable=False)
    percentual = db.Column(db.Float, default=0.0)
    em_progresso = db.Column(db.Boolean, default=False)
    inicio_em = db.Column(db.DateTime, nullable=True)
    horario_conclusao = db.Column(db.DateTime, nullable=True)

    @classmethod
    def obter_ou_criar(cls, equipe_id):
        registro = cls.query.filter_by(equipe_id=equipe_id).first()
        if not registro:
            registro = cls(equipe_id=equipe_id)
            db.session.add(registro)
            db.session.commit()
        return registro


# ---------------------------------------------------------
# EQUIPE (pertence a um usuário) e histórico de resultados
# ---------------------------------------------------------

class EquipeDB(db.Model):
    __tablename__ = "equipes"

    id = db.Column(db.Integer, primary_key=True)
    usuario_id = db.Column(db.Integer, db.ForeignKey("usuarios.id"), unique=True, nullable=False)
    nome = db.Column(db.String(100), nullable=False)
    orcamento = db.Column(db.Float, default=1_000_000.0)

    motor_fornecedor_id = db.Column(db.Integer, db.ForeignKey("fornecedores_motor.id"), nullable=False)
    combustivel_fornecedor_id = db.Column(db.Integer, db.ForeignKey("fornecedores_combustivel.id"), nullable=False)
    pneu_fornecedor_id = db.Column(db.Integer, db.ForeignKey("fornecedores_pneu.id"), nullable=False)
    chassi_fornecedor_id = db.Column(db.Integer, db.ForeignKey("fornecedores_chassi.id"), nullable=False)
    cambio_fornecedor_id = db.Column(db.Integer, db.ForeignKey("fornecedores_cambio.id"), nullable=False)
    suspensao_fornecedor_id = db.Column(db.Integer, db.ForeignKey("fornecedores_suspensao.id"), nullable=False)

    engenheiro_fornecedor_id = db.Column(db.Integer, db.ForeignKey("fornecedores_engenheiro.id"), nullable=True)

    combustivel_carregado = db.Column(db.Float, default=110.0)

    cor_primaria = db.Column(db.String(7), default="#cc0000")
    cor_secundaria = db.Column(db.String(7), default="#ffffff")

    def montar_carro(self):
        """Constrói o objeto de domínio Carro a partir dos dados salvos."""
        from equipamentos import Motor, Combustivel, Pneu, Chassi, Cambio, Suspensao, Engenheiro
        from equipe import Equipe
        from carro import Carro

        motor_db = FornecedorMotor.query.get(self.motor_fornecedor_id)
        combustivel_db = FornecedorCombustivel.query.get(self.combustivel_fornecedor_id)
        pneu_db = FornecedorPneu.query.get(self.pneu_fornecedor_id)
        chassi_db = FornecedorChassi.query.get(self.chassi_fornecedor_id)
        cambio_db = FornecedorCambio.query.get(self.cambio_fornecedor_id)
        suspensao_db = FornecedorSuspensao.query.get(self.suspensao_fornecedor_id)

        engenheiro_db = (
            FornecedorEngenheiro.query.get(self.engenheiro_fornecedor_id)
            if self.engenheiro_fornecedor_id else None
        )

        equipe = Equipe(self.nome, self.orcamento)
        motor = Motor(motor_db.nome, motor_db.custo_temporada, motor_db.potencia, motor_db.eficiencia_combustivel)
        combustivel = Combustivel(combustivel_db.nome, combustivel_db.custo_temporada, combustivel_db.eficiencia,
                                   combustivel_db.aumento_potencia_motor)
        pneu = Pneu(pneu_db.nome, pneu_db.custo_temporada, pneu_db.performance, pneu_db.desgaste)
        chassi = Chassi(chassi_db.nome, chassi_db.custo_temporada, chassi_db.performance)
        cambio = Cambio(cambio_db.nome, cambio_db.custo_temporada, cambio_db.performance)
        suspensao = Suspensao(suspensao_db.nome, suspensao_db.custo_temporada, suspensao_db.performance)

        engenheiro = None
        if engenheiro_db:
            desenvolvimento = Desenvolvimento.obter_ou_criar(self.id)
            eficiencia_efetiva = engenheiro_db.eficiencia_exata * (desenvolvimento.percentual / 100)
            engenheiro = Engenheiro(engenheiro_db.nome, engenheiro_db.custo_temporada,
                                     engenheiro_db.nivel, eficiencia_efetiva)

        config = Configuracao.obter()
        treinamento = TreinamentoBox.obter_ou_criar(self.id)
        tempo_pit_stop = config.pit_tempo_sem_treino - (
            (config.pit_tempo_sem_treino - config.pit_tempo_treino_completo) * (treinamento.percentual / 100)
        )

        return Carro(
            equipe=equipe, motor=motor, combustivel=combustivel, pneu=pneu, chassi=chassi,
            cambio=cambio, suspensao=suspensao,
            engenheiro=engenheiro,
            combustivel_carregado=self.combustivel_carregado,
            tempo_pit_stop=tempo_pit_stop,
        )

    def custo_total_montagem(self):
        """Soma o custo de MONTAGEM (por corrida) de todos os itens escolhidos."""
        total = 0.0
        for modelo, campo_id in [
            (FornecedorMotor, self.motor_fornecedor_id),
            (FornecedorCombustivel, self.combustivel_fornecedor_id),
            (FornecedorPneu, self.pneu_fornecedor_id),
            (FornecedorChassi, self.chassi_fornecedor_id),
            (FornecedorCambio, self.cambio_fornecedor_id),
            (FornecedorSuspensao, self.suspensao_fornecedor_id),
        ]:
            item = modelo.query.get(campo_id)
            if item:
                total += item.custo_montagem
        if self.engenheiro_fornecedor_id:
            engenheiro = FornecedorEngenheiro.query.get(self.engenheiro_fornecedor_id)
            if engenheiro:
                total += engenheiro.custo_montagem
        return total


class ResultadoClassificacao(db.Model):
    __tablename__ = "resultados_classificacao"

    id = db.Column(db.Integer, primary_key=True)
    equipe_id = db.Column(db.Integer, db.ForeignKey("equipes.id"), nullable=False)
    tempo_classificacao = db.Column(db.Float)
    posicao_grid = db.Column(db.Integer)
    criado_em = db.Column(db.DateTime, default=datetime.utcnow)

    equipe = db.relationship("EquipeDB")


class ResultadoCorrida(db.Model):
    __tablename__ = "resultados_corrida"

    id = db.Column(db.Integer, primary_key=True)
    equipe_id = db.Column(db.Integer, db.ForeignKey("equipes.id"), nullable=False)
    tempo_total_segundos = db.Column(db.Float)
    pit_stops = db.Column(db.Integer)
    posicao_final = db.Column(db.Integer)
    criado_em = db.Column(db.DateTime, default=datetime.utcnow)

    equipe = db.relationship("EquipeDB")
